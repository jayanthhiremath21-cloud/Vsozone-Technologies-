import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { products } from "@/lib/site-data";
import { Section, ProductCard, EnquiryCta } from "@/components/site/pieces";
import { useEnquiry } from "@/components/site/enquiry";

export const Route = createFileRoute("/products/$slug")({
  loader: ({ params }) => {
    const product = products.find((p) => p.slug === params.slug);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Product not found — VSOZONE" }, { name: "robots", content: "noindex" }] };
    }
    const { product } = loaderData;
    return {
      meta: [
        { title: `${product.name} — ${product.category} | VSOZONE` },
        { name: "description", content: product.short },
        { property: "og:title", content: `${product.name} | VSOZONE Technologies` },
        { property: "og:description", content: product.short },
      ],
    };
  },
  component: ProductDetail,
});

function ProductDetail() {
  const { product } = Route.useLoaderData();
  const { open } = useEnquiry();
  const related = products.filter((p) => p.categorySlug === product.categorySlug && p.slug !== product.slug).slice(0, 3);

  const specs = [
    ["Capacity", product.capacity],
    ["Accuracy", product.accuracy],
    ["Construction", product.construction],
    ["Display", product.display],
    ["Application", product.application],
  ].filter(([, v]) => Boolean(v)) as [string, string][];

  return (
    <>
      <Section tone="muted">
        <nav className="text-sm text-muted-foreground">
          <Link to="/products" search={{}} className="hover:text-primary">
            Products
          </Link>
          <span className="mx-2">/</span>
          <span className="text-foreground/80">{product.name}</span>
        </nav>

        <div className="mt-8 grid gap-10 lg:grid-cols-2 lg:items-start">
          <div className="overflow-hidden rounded-xl border border-border bg-card">
            <img src={product.image} alt={product.name} className="aspect-[4/3] w-full object-cover" />
          </div>
          <div>
            <p className="eyebrow">{product.category}</p>
            <h1 className="mt-3 text-3xl font-extrabold leading-tight text-primary sm:text-4xl">
              {product.name}
            </h1>
            <div aria-hidden className="mt-5 rule-gold" />
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">{product.short}</p>

            <dl className="mt-8 divide-y divide-border rounded-lg border border-border bg-card">
              {specs.map(([k, v]) => (
                <div key={k} className="flex flex-col gap-1 p-4 sm:flex-row sm:gap-6">
                  <dt className="w-40 shrink-0 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    {k}
                  </dt>
                  <dd className="text-sm font-medium text-foreground">{v}</dd>
                </div>
              ))}
            </dl>

            <ul className="mt-8 grid gap-2 sm:grid-cols-2">
              {product.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm text-foreground/85">
                  <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-gold" />
                  {f}
                </li>
              ))}
            </ul>

            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" onClick={() => open(product.name)}>
                Request a Quote
              </Button>
              <Button size="lg" variant="outlineGold" asChild>
                <Link to="/contact">Talk to an Engineer</Link>
              </Button>
            </div>
          </div>
        </div>

        {related.length ? (
          <div className="mt-20">
            <h2 className="text-2xl font-bold text-primary">Related products</h2>
            <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((p, i) => (
                <ProductCard key={p.slug} product={p} delay={i * 40} />
              ))}
            </div>
          </div>
        ) : null}
      </Section>
      <EnquiryCta />
    </>
  );
}

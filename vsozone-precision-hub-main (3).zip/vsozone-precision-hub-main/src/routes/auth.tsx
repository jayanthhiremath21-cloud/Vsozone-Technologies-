import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LOGO_URL } from "@/components/site/logo";
import { COMPANY } from "@/lib/site-data";
import { uploadAvatar } from "@/lib/avatar";

const searchSchema = z.object({
  redirect: z.string().optional(),
});

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Sign In — VSOZONE Technologies Customer Portal" },
      {
        name: "description",
        content:
          "Sign in or create your VSOZONE Technologies account to manage your profile, enquiries and orders.",
      },
      { property: "og:title", content: "Sign In — VSOZONE Technologies" },
      { property: "og:description", content: "Access your VSOZONE customer portal." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

const emailSchema = z.string().trim().email("Enter a valid email address").max(255);
const passwordSchema = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .max(72)
  .regex(/[A-Za-z]/, "Password must contain a letter")
  .regex(/[0-9]/, "Password must contain a number");
const usernameSchema = z
  .string()
  .trim()
  .min(3, "Username must be at least 3 characters")
  .max(30, "Username must be 30 characters or fewer")
  .regex(/^[a-zA-Z0-9._-]+$/, "Use letters, numbers, dots, underscores or hyphens only");

type Mode = "login" | "signup" | "forgot";

function safePath(value?: string) {
  if (!value) return null;
  if (!value.startsWith("/") || value.startsWith("//")) return null;
  return value;
}

function AuthPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const [mode, setMode] = useState<Mode>("login");
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [usernameState, setUsernameState] = useState<"idle" | "checking" | "free" | "taken">("idle");
  const [photo, setPhoto] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const destination = safePath(search.redirect) ?? "/profile";

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: destination, replace: true });
    });
  }, [navigate, destination]);

  useEffect(() => {
    if (mode !== "signup") return;
    const parsed = usernameSchema.safeParse(username);
    if (!parsed.success) {
      setUsernameState("idle");
      return;
    }
    setUsernameState("checking");
    const t = setTimeout(async () => {
      const { data, error: err } = await supabase.rpc("is_username_available", {
        _username: parsed.data,
      });
      if (err) return setUsernameState("idle");
      setUsernameState(data ? "free" : "taken");
    }, 400);
    return () => clearTimeout(t);
  }, [username, mode]);

  async function signInWithGoogle() {
    setError(null);
    try {
      sessionStorage.setItem("vsozone:after-login", destination);
      await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Google sign-in failed. Please try again.");
    }
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSent(null);

    const parsedEmail = emailSchema.safeParse(email);
    if (!parsedEmail.success) {
      setError(parsedEmail.error.issues[0]?.message ?? "Invalid email");
      return;
    }

    setLoading(true);
    try {
      if (mode === "forgot") {
        const { error: err } = await supabase.auth.resetPasswordForEmail(parsedEmail.data, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (err) throw err;
        setSent("Password reset link sent. Check your inbox.");
        return;
      }

      if (mode === "signup") {
        const parsedPassword = passwordSchema.safeParse(password);
        if (!parsedPassword.success) {
          setError(parsedPassword.error.issues[0]?.message ?? "Invalid password");
          return;
        }
        if (password !== confirm) {
          setError("Passwords do not match");
          return;
        }
        const name = fullName.trim().slice(0, 80);
        if (name.length < 2) {
          setError("Please enter your full name");
          return;
        }
        const parsedUsername = usernameSchema.safeParse(username);
        if (!parsedUsername.success) {
          setError(parsedUsername.error.issues[0]?.message ?? "Invalid username");
          return;
        }
        const { data: available } = await supabase.rpc("is_username_available", {
          _username: parsedUsername.data,
        });
        if (!available) {
          setError("That username is already taken. Please choose another.");
          return;
        }

        const { data, error: err } = await supabase.auth.signUp({
          email: parsedEmail.data,
          password: parsedPassword.data,
          options: {
            emailRedirectTo: `${window.location.origin}/profile`,
            data: {
              full_name: name,
              display_name: name,
              username: parsedUsername.data,
            },
          },
        });
        if (err) throw err;

        if (data.session && photo && data.user) {
          try {
            const path = await uploadAvatar(data.user.id, photo);
            await supabase.from("profiles").update({ avatar_url: path }).eq("id", data.user.id);
          } catch {
            /* non-fatal: photo can be added later from the profile page */
          }
        }

        if (!data.session) {
          setSent(
            "Account created. Please check your email and confirm your address before signing in.",
          );
          return;
        }
        toast.success("Welcome to VSOZONE");
        navigate({ to: destination, replace: true });
        return;
      }

      const { error: err } = await supabase.auth.signInWithPassword({
        email: parsedEmail.data,
        password,
      });
      if (err) throw err;
      toast.success("Welcome back");
      navigate({ to: destination, replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative flex min-h-[80vh] items-center justify-center overflow-hidden surface-deep px-4 py-16">
      <div aria-hidden className="pointer-events-none absolute inset-0 opacity-[0.12]">
        <div className="size-full bg-[linear-gradient(to_right,var(--color-gold)_1px,transparent_1px),linear-gradient(to_bottom,var(--color-gold)_1px,transparent_1px)] bg-[size:72px_72px]" />
      </div>
      <div className="relative w-full max-w-md rounded-xl border border-gold/25 bg-background p-8 shadow-[0_40px_90px_-50px_rgba(0,0,0,0.7)]">
        <img
          src={LOGO_URL}
          alt="VSOZONE Technologies"
          className="mx-auto h-14 w-auto object-contain mix-blend-multiply"
        />
        <h1 className="mt-6 text-center text-2xl font-extrabold text-primary">
          {mode === "login"
            ? "Welcome Back"
            : mode === "signup"
              ? "Create Your Account"
              : "Reset Password"}
        </h1>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          {mode === "forgot"
            ? "We'll email you a secure reset link."
            : `${COMPANY.brand} Customer Portal — ${COMPANY.tagline}`}
        </p>
        <div aria-hidden className="mx-auto mt-5 rule-gold" />

        {mode !== "forgot" ? (
          <>
            <button
              type="button"
              onClick={signInWithGoogle}
              className="mt-6 flex w-full items-center justify-center gap-3 rounded-lg border border-border bg-card px-4 py-3 text-sm font-semibold text-foreground shadow-sm transition-all duration-200 hover:border-gold/60 hover:shadow-md focus-visible:ring-2 focus-visible:ring-gold/50 focus-visible:outline-none"
            >
              <GoogleIcon />
              Continue with Google
            </button>
            <div className="my-5 flex items-center gap-3 text-[0.7rem] font-semibold tracking-widest text-muted-foreground uppercase">
              <span className="h-px flex-1 bg-border" /> or <span className="h-px flex-1 bg-border" />
            </div>
          </>
        ) : null}

        <form onSubmit={onSubmit} className="space-y-4">
          {mode === "signup" ? (
            <>
              <Field label="Full Name" htmlFor="fullName">
                <Input id="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  maxLength={80}
                  required
                  autoComplete="name"
                />
              </Field>
              <Field label="Username" htmlFor="username">
                <Input id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  maxLength={30}
                  required
                  autoComplete="username"
                  placeholder="e.g. veeresh_v"
                />
                {usernameState === "checking" ? (
                  <p className="text-xs text-muted-foreground">Checking availability…</p>
                ) : usernameState === "free" ? (
                  <p className="text-xs font-medium text-primary">Username is available</p>
                ) : usernameState === "taken" ? (
                  <p className="text-xs font-medium text-destructive">Username already taken</p>
                ) : null}
              </Field>
              <Field label="Profile Photo (optional)">
                <div className="flex items-center gap-3">
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => setPhoto(e.target.files?.[0] ?? null)}
                  />
                  <Button type="button" variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                    Choose photo
                  </Button>
                  <span className="truncate text-xs text-muted-foreground">
                    {photo ? photo.name : "No file selected"}
                  </span>
                </div>
              </Field>
            </>
          ) : null}

          <Field label="Email" htmlFor="email">
            <Input id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              maxLength={255}
              required
              autoComplete="email"
            />
          </Field>

          {mode !== "forgot" ? (
            <Field label="Password" htmlFor="password">
              <Input id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete={mode === "signup" ? "new-password" : "current-password"}
              />
            </Field>
          ) : null}

          {mode === "signup" ? (
            <Field label="Confirm Password" htmlFor="confirm">
              <Input id="confirm"
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                required
                autoComplete="new-password"
              />
            </Field>
          ) : null}

          {error ? (
            <p
              role="alert"
              className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
            >
              {error}
            </p>
          ) : null}
          {sent ? (
            <p className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm text-primary">
              {sent}
            </p>
          ) : null}

          <Button type="submit" size="lg" className="w-full" disabled={loading}>
            {loading
              ? "Please wait…"
              : mode === "login"
                ? "Login"
                : mode === "signup"
                  ? "Create Account"
                  : "Send Reset Link"}
          </Button>
        </form>

        <div className="mt-6 space-y-2 text-center text-sm">
          {mode === "login" ? (
            <>
              <button
                type="button"
                className="text-muted-foreground hover:text-primary"
                onClick={() => setMode("forgot")}
              >
                Forgot password?
              </button>
              <p className="text-muted-foreground">
                New here?{" "}
                <button
                  type="button"
                  className="font-semibold text-primary hover:text-gold"
                  onClick={() => setMode("signup")}
                >
                  Create Account
                </button>
              </p>
            </>
          ) : (
            <button
              type="button"
              className="font-semibold text-primary hover:text-gold"
              onClick={() => setMode("login")}
            >
              Back to login
            </button>
          )}
          <p>
            <Link to="/" className="text-xs text-muted-foreground hover:text-primary">
              ← Back to vsozone.com website
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 48 48" className="size-5" aria-hidden>
      <path
        fill="#EA4335"
        d="M24 9.5c3.5 0 6.6 1.2 9 3.6l6.7-6.7C35.6 2.6 30.2 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.8 6.1C12.3 13.2 17.6 9.5 24 9.5Z"
      />
      <path
        fill="#4285F4"
        d="M46.1 24.6c0-1.6-.1-2.8-.4-4.1H24v7.8h12.6c-.3 2.1-1.6 5.2-4.7 7.3l7.6 5.9c4.5-4.2 6.6-10.3 6.6-16.9Z"
      />
      <path
        fill="#FBBC05"
        d="M10.4 28.6a14.6 14.6 0 0 1 0-9.3l-7.8-6.1a24 24 0 0 0 0 21.5l7.8-6.1Z"
      />
      <path
        fill="#34A853"
        d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2 1.4-4.8 2.4-8.3 2.4-6.4 0-11.7-3.7-13.6-9.8l-7.8 6.1C6.5 42.6 14.6 48 24 48Z"
      />
    </svg>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={htmlFor} className="text-xs font-semibold tracking-wide uppercase text-muted-foreground">
        {label}
      </Label>
      {children}
    </div>
  );
}

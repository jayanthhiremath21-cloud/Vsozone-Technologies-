import { createFileRoute } from "@tanstack/react-router";
import { FileText, HelpCircle, Wrench } from "lucide-react";
import { Section, SectionHead, EnquiryCta } from "@/components/site/pieces";
import { Reveal } from "@/components/site/reveal";

const guides = [
  {
    icon: FileText,
    title: "Choosing the right capacity",
    body: "Match platform size, capacity and readability to your heaviest routine load, not your rarest one.",
  },
  {
    icon: Wrench,
    title: "Weighbridge site preparation",
    body: "Foundation, approach length and drainage decide long-term accuracy. We survey before recommending.",
  },
  {
    icon: HelpCircle,
    title: "Why AMC matters",
    body: "Scheduled maintenance keeps calibration stable and prevents unplanned downtime at your counter or yard.",
  },
];

const faqs = [
  {
    q: "What capacities do your weighbridges cover?",
    a: "Our electronic weighbridges cover a 10 Ton to 500 Ton range. The right choice depends on vehicle type and traffic volume.",
  },
  {
    q: "Do you provide installation and commissioning?",
    a: "Yes. Every system includes on-site installation, commissioning, verification and handover by our service team.",
  },
  {
    q: "Which regions do you serve?",
    a: "North Karnataka including Kalaburagi, Bidar, Yadgir, Vijayapura, Bagalkot, Ballari, Raichur, Mangaluru and Karwar, plus Goa and Maharashtra.",
  },
  {
    q: "Are spare parts available after purchase?",
    a: "Yes — genuine spare parts, repair support and annual maintenance contracts are available for installed equipment.",
  },
];

export const Route = createFileRoute("/resources")({
  head: () => ({
    meta: [
      { title: "Resources & FAQs — Weighing and Weighbridge Guidance | VSOZONE" },
      {
        name: "description",
        content:
          "Practical guidance on capacity selection, weighbridge site preparation, AMC value and answers to common weighing equipment questions.",
      },
      { property: "og:title", content: "VSOZONE Resources — Guides & FAQs" },
      {
        property: "og:description",
        content: "Buying guidance and frequently asked questions about weighing, cash and security equipment.",
      },
    ],
  }),
  component: ResourcesPage,
});

function ResourcesPage() {
  return (
    <>
      <Section tone="muted">
        <SectionHead
          eyebrow="Resources"
          title="Guidance before you invest"
          subtitle="Short, practical notes drawn from two decades of installations across industry and retail."
        />
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {guides.map((g, i) => (
            <Reveal key={g.title} delay={i * 50}>
              <article className="card-lift h-full rounded-xl border border-border bg-card p-6">
                <g.icon className="size-5 text-gold" />
                <h3 className="mt-4 text-base font-bold text-primary">{g.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{g.body}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHead eyebrow="FAQ" title="Frequently asked questions" />
        <div className="mt-10 divide-y divide-border rounded-xl border border-border bg-card">
          {faqs.map((f) => (
            <div key={f.q} className="p-6">
              <h3 className="text-base font-bold text-primary">{f.q}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
            </div>
          ))}
        </div>
      </Section>
      <EnquiryCta />
    </>
  );
}

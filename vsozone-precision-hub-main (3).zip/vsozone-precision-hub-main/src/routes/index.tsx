import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MessageCircle, Phone, ShieldCheck, Wrench, MapPin, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  COMPANY,
  WHATSAPP_TEMPLATE,
  categories,
  industries,
  products,
  services,
  images,
} from "@/lib/site-data";
import {
  Section,
  SectionHead,
  CategoryCard,
  ProductCard,
  ServiceJourney,
} from "@/components/site/pieces";
import { Reveal } from "@/components/site/reveal";
import { WhyCarousel } from "@/components/site/why-carousel";
import { useEnquiry } from "@/components/site/enquiry";
import founderAsset from "@/assets/founder-veeresh.jpg.asset.json";

const whatsappLink = `${COMPANY.whatsappHref}?text=${encodeURIComponent(WHATSAPP_TEMPLATE)}`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VSOZONE Technologies — Weighing, Weighbridges & Security Solutions" },
      {
        name: "description",
        content:
          "V.S. Ozone Technologies, Kalaburagi — precision weighing machines, electronic weighbridges, cash counting, billing, CCTV and safety lockers. Where Accuracy Meets Quality.",
      },
      { property: "og:title", content: "VSOZONE Technologies — Where Accuracy Meets Quality" },
      {
        property: "og:description",
        content:
          "Advanced weighing, industrial, security and business technology solutions engineered for accuracy and reliability.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const featuredSlugs = [
  "jewellery-model-vte",
  "candy-scale",
  "table-top-scale",
  "personal-baby-scale",
  "roller-platform",
  "platform-ch",
  "platform-ss",
  "heavy-platform-ch",
];

const trust = [
  { icon: Gauge, headline: "20+ Years", label: "Engineering Experience" },
  { icon: ShieldCheck, headline: "Precision", label: "Weighing Solutions" },
  { icon: Wrench, headline: "Complete Support", label: "Installation • AMC • Repair" },
  { icon: MapPin, headline: "Regional Service", label: "Karnataka & Beyond" },
];

const campaignCategories = [
  { title: "Weighing Machines", category: "weighing-machines", image: images.prodPlatform },
  { title: "CCTV Cameras", category: "security", image: images.sceneSecurity },
  { title: "Cash Counting", category: "cash-billing", image: images.prodCash },
  { title: "Safety Lockers", category: "security", image: images.sceneSecurity },
  { title: "Jewellery Scales", category: "weighing-machines", image: images.prodJewellery },
  { title: "Weighbridges", category: "weighbridges", image: images.heroIndustrial },
] as const;

function Index() {
  const { open } = useEnquiry();
  const featured = featuredSlugs
    .map((slug) => products.find((p) => p.slug === slug))
    .filter((p): p is (typeof products)[number] => Boolean(p));

  return (
    <>
      {/* 03 — HERO */}
      <section className="relative overflow-hidden surface-deep">
        <div aria-hidden className="pointer-events-none absolute inset-0 opacity-[0.14]">
          <div className="size-full bg-[linear-gradient(to_right,var(--color-gold)_1px,transparent_1px),linear-gradient(to_bottom,var(--color-gold)_1px,transparent_1px)] bg-[size:72px_72px]" />
        </div>
        <div
          aria-hidden
          className="pointer-events-none absolute -top-32 right-0 size-[38rem] rounded-full bg-gold/12 blur-[120px]"
        />
        <div className="relative mx-auto grid max-w-7xl gap-14 px-4 py-20 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:gap-10 lg:px-6 lg:py-28">
          <Reveal>
            <p className="text-xs font-bold tracking-[0.32em] text-gold uppercase">
              Precision • Security • Reliability
            </p>
            <h1 className="mt-6 text-4xl leading-[1.05] font-extrabold text-deep-foreground sm:text-5xl lg:text-6xl">
              Engineering Precision.
              <span className="block text-gold-gradient">Building Trust.</span>
            </h1>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-deep-foreground/75 sm:text-lg">
              Advanced weighing, industrial, security and business technology solutions designed for
              accuracy, reliability and long-term performance.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Button asChild variant="gold" size="lg">
                <Link to="/products">
                  Explore Products
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button variant="outlineLight" size="lg" onClick={() => open()}>
                Get a Quote
              </Button>
            </div>
            <p className="mt-8 text-sm text-deep-foreground/55">
              Serving businesses with dependable technology solutions.
            </p>
          </Reveal>

          <Reveal delay={140} className="relative">
            <div aria-hidden className="absolute inset-x-6 top-10 bottom-0 rounded-t-[3rem] bg-gradient-to-t from-gold/25 to-transparent blur-2xl" />
            <div className="relative overflow-hidden rounded-xl border border-gold/25 bg-ink/50">
              <div aria-hidden className="absolute inset-0 bg-[radial-gradient(circle_at_70%_20%,oklch(0.8_0.13_85/0.25),transparent_60%)]" />
              <img
                src={founderAsset.url}
                alt="Veeresh Vishwanth, Founder of VSOZONE Technologies"
                className="relative mx-auto h-[26rem] w-full object-contain object-bottom sm:h-[32rem]"
              />
              <div className="relative border-t border-gold/20 bg-deep/85 px-6 py-4 backdrop-blur">
                <p className="text-sm font-bold text-deep-foreground">Veeresh Vishwanth</p>
                <p className="text-xs tracking-[0.18em] text-gold uppercase">Founder & Visionary Leader</p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 04 — TRUST STRIP */}
      <section className="border-b border-border bg-secondary/60 px-4 py-12 lg:px-6">
        <div className="mx-auto grid max-w-7xl gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {trust.map((item, i) => (
            <Reveal key={item.headline} delay={i * 80}>
              <div className="card-lift flex h-full items-start gap-4 rounded-xl border border-border bg-card p-6">
                <span className="grid size-11 shrink-0 place-items-center rounded-md bg-primary/8 text-gold ring-1 ring-gold/30">
                  <item.icon className="size-5" />
                </span>
                <div>
                  <p className="text-base font-extrabold tracking-tight text-primary uppercase">
                    {item.headline}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">{item.label}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* 05 — PRODUCT CATEGORIES */}
      <Section>
        <SectionHead
          eyebrow="Product Range"
          title="Technology for Every Requirement"
          subtitle="From precision jewellery weighing to heavy-duty industrial weighing infrastructure."
        />
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {categories.map((category, i) => (
            <CategoryCard key={category.slug} category={category} delay={i * 70} />
          ))}
        </div>
      </Section>

      {/* 06 — FEATURED WEIGHING SOLUTIONS */}
      <Section tone="muted">
        <SectionHead
          eyebrow="Featured"
          title="Precision Weighing Solutions"
          subtitle="Electronic weighing systems across jewellery, retail, commercial and industrial duty."
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((product, i) => (
            <ProductCard key={product.slug} product={product} delay={i * 60} />
          ))}
        </div>
      </Section>

      {/* 07 — WEIGHBRIDGE HERO */}
      <section className="relative overflow-hidden">
        <img
          src={images.heroIndustrial}
          alt="Electronic weighbridge installation"
          loading="lazy"
          className="absolute inset-0 size-full object-cover"
        />
        <div aria-hidden className="absolute inset-0 bg-gradient-to-r from-deep via-deep/90 to-deep/40" />
        <div className="relative mx-auto max-w-7xl px-4 py-24 lg:px-6 lg:py-32">
          <Reveal className="max-w-2xl">
            <p className="eyebrow text-gold">Weighbridges</p>
            <h2 className="mt-4 text-3xl leading-tight font-extrabold text-deep-foreground sm:text-4xl lg:text-5xl">
              Heavy-Duty Weighing. Built for Industry.
            </h2>
            <p className="mt-5 text-base leading-relaxed text-deep-foreground/75 sm:text-lg">
              Reliable weighing infrastructure for logistics, transport, manufacturing and industrial
              operations.
            </p>
            <p className="mt-8 text-2xl font-extrabold tracking-[0.12em] text-gold-gradient sm:text-3xl">
              10 TONNES – 500 TONNES
            </p>
            <Button asChild variant="gold" size="lg" className="mt-8">
              <Link to="/products" search={{ category: "weighbridges" }}>
                Explore Weighbridges
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          </Reveal>
        </div>
      </section>

      {/* 08 — WHY CHOOSE VSOZONE */}
      <Section tone="deep">
        <SectionHead
          tone="deep"
          align="center"
          eyebrow="Why VSOZONE"
          title="Why Choose VSOZONE?"
          subtitle="Quality You Can Trust. Technology You Can Rely On."
        />
        <WhyCarousel />

        {/* 09 — CAMPAIGN CATEGORY NAV */}
        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {campaignCategories.map((item, i) => (
            <Reveal key={item.title} delay={i * 60}>
              <Link
                to="/products"
                search={{ category: item.category }}
                className="group relative flex h-32 items-end overflow-hidden rounded-xl border border-gold/25"
              >
                <img
                  src={item.image}
                  alt=""
                  loading="lazy"
                  className="absolute inset-0 size-full object-cover transition-transform duration-[900ms] group-hover:scale-105"
                />
                <span aria-hidden className="absolute inset-0 bg-gradient-to-t from-ink/90 to-ink/25" />
                <span className="relative flex w-full items-center justify-between px-5 pb-4 text-sm font-bold tracking-[0.16em] text-deep-foreground uppercase">
                  {item.title}
                  <ArrowRight className="size-4 text-gold transition-transform duration-300 group-hover:translate-x-1" />
                </span>
              </Link>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* 10 — SERVICES */}
      <Section>
        <SectionHead
          eyebrow="Service Ecosystem"
          title="More Than Products. Complete Support."
          subtitle="Consultation to spare parts — one accountable engineering partner across the equipment lifecycle."
        />
        <div className="mt-12">
          <ServiceJourney />
        </div>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.slice(0, 6).map((service, i) => (
            <Reveal key={service.name} delay={i * 60}>
              <article className="card-lift h-full rounded-xl border border-border bg-card p-6">
                <span className="grid size-10 place-items-center rounded-md bg-primary/8 text-gold ring-1 ring-gold/30">
                  <Wrench className="size-4" />
                </span>
                <h3 className="mt-4 text-base font-bold text-primary">{service.name}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {service.description}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
        <div className="mt-10">
          <Button asChild size="lg">
            <Link to="/services">
              Book a Service
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>
      </Section>

      {/* 11 — INDUSTRIES */}
      <Section tone="muted">
        <SectionHead
          eyebrow="Industries"
          title="Solutions for Real-World Industries"
          subtitle="Engineered for the operating realities of each sector we serve."
        />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {industries.slice(0, 9).map((industry, i) => (
            <Reveal key={industry.name} delay={i * 50}>
              <Link
                to="/industries"
                className="group relative flex h-52 items-end overflow-hidden rounded-xl border border-border"
              >
                <img
                  src={industry.image}
                  alt={industry.name}
                  loading="lazy"
                  className="absolute inset-0 size-full object-cover transition-transform duration-[900ms] group-hover:scale-105"
                />
                <span aria-hidden className="absolute inset-0 bg-gradient-to-t from-ink/92 via-ink/45 to-transparent" />
                <div className="relative p-5">
                  <h3 className="text-lg font-bold text-deep-foreground">{industry.name}</h3>
                  <p className="mt-1.5 text-sm text-deep-foreground/70">{industry.description}</p>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* 12 — ABOUT */}
      <Section>
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <Reveal>
            <p className="eyebrow">About VSOZONE</p>
            <h2 className="mt-3 text-3xl font-extrabold leading-tight text-primary sm:text-4xl">
              An Indian engineering and technology company built on accuracy.
            </h2>
            <div aria-hidden className="mt-5 rule-gold" />
            <p className="mt-6 text-base leading-relaxed text-muted-foreground">
              V.S. Ozone Technologies is an Indian engineering and technology company based in
              Kalaburagi, Karnataka, delivering weighing, industrial, security, cash-handling and
              business technology solutions.
            </p>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              Established in {COMPANY.established}, the company works to a single motto —{" "}
              <span className="font-semibold text-primary">“{COMPANY.tagline}”</span>.
            </p>
            <Button asChild variant="outline" size="lg" className="mt-8">
              <Link to="/about">
                Learn More About Us
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          </Reveal>
          <Reveal delay={120}>
            <div className="overflow-hidden rounded-xl border border-border bg-secondary">
              <img
                src={founderAsset.url}
                alt="Veeresh Vishwanth, Founder of VSOZONE Technologies"
                loading="lazy"
                className="mx-auto h-[24rem] w-full object-contain sm:h-[28rem]"
              />
            </div>
          </Reveal>
        </div>
      </Section>

      {/* 13 — FOUNDER */}
      <Section tone="deep">
        <div className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:items-center">
          <Reveal>
            <div className="overflow-hidden rounded-xl border border-gold/25 bg-ink/40">
              <img
                src={founderAsset.url}
                alt="Portrait of Veeresh Vishwanth"
                loading="lazy"
                className="mx-auto h-[24rem] w-full object-contain"
              />
            </div>
          </Reveal>
          <Reveal delay={120}>
            <p className="eyebrow text-gold">Leadership</p>
            <h2 className="mt-3 text-3xl font-extrabold text-deep-foreground sm:text-4xl">
              Veeresh Vishwanth
            </h2>
            <p className="mt-2 text-sm font-semibold tracking-[0.2em] text-gold uppercase">
              Founder & Visionary Leader
            </p>
            <div aria-hidden className="mt-5 rule-gold" />
            <p className="mt-6 text-base leading-relaxed text-deep-foreground/75">
              Veeresh Vishwanth represents the leadership vision behind VSOZONE Technologies, with a
              focus on building a trusted technology and engineering business around accuracy,
              dependable products and long-term customer relationships.
            </p>
          </Reveal>
        </div>
      </Section>

      {/* 14 — FINAL CTA */}
      <section className="relative overflow-hidden bg-primary px-4 py-24 lg:px-6 lg:py-28">
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-40 left-1/2 size-[42rem] -translate-x-1/2 rounded-full bg-gold/14 blur-[130px]"
        />
        <div className="relative mx-auto max-w-3xl text-center">
          <Reveal>
            <h2 className="text-3xl font-extrabold leading-tight text-primary-foreground sm:text-4xl lg:text-5xl">
              Your Business. <span className="block text-gold-gradient">Our Trust.</span>
            </h2>
            <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-primary-foreground/75 sm:text-lg">
              Choose VSOZONE Technologies for solutions built around accuracy, security and
              reliability.
            </p>
            <div className="mt-9 flex flex-wrap justify-center gap-3">
              <Button variant="gold" size="lg" onClick={() => open()}>
                Get a Quote
              </Button>
              <Button asChild variant="outlineLight" size="lg">
                <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="size-4" />
                  WhatsApp Us
                </a>
              </Button>
            </div>
            <a
              href={COMPANY.phoneHref}
              className="mt-8 inline-flex items-center gap-2 text-lg font-bold text-gold hover:underline"
            >
              <Phone className="size-5" />
              {COMPANY.phone}
            </a>
          </Reveal>
        </div>
      </section>
    </>
  );
}

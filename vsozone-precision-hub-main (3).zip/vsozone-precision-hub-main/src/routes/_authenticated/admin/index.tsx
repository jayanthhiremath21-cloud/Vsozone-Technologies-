import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ShoppingCart,
  IndianRupee,
  PackageX,
  Star,
  Users,
  TicketPercent,
  Truck,
  LifeBuoy,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AdminShell } from "@/components/admin/shell";
import { Button } from "@/components/ui/button";
import { formatINR } from "@/lib/crm";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — VSOZONE Technologies" },
      { name: "description", content: "Live business metrics for VSOZONE Technologies." },
      { property: "og:title", content: "Admin Dashboard — VSOZONE Technologies" },
      { property: "og:description", content: "Live business metrics for VSOZONE Technologies." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminDashboard,
});

type Metrics = {
  todays_orders: number;
  todays_sales: number;
  total_revenue: number;
  pending_orders: number;
  to_dispatch: number;
  delivered_orders: number;
  cancelled_orders: number;
  return_requests: number;
  low_stock: number;
  out_of_stock: number;
  new_customers: number;
  new_reviews: number;
  average_rating: number;
  active_coupons: number;
  not_deliverable: number;
  open_tickets: number;
  sales_by_city: { city: string; orders: number; revenue: number }[];
};

function Kpi({
  label,
  value,
  icon: Icon,
  tone,
}: {
  label: string;
  value: string | number;
  icon: typeof Users;
  tone?: "gold" | "danger";
}) {
  return (
    <div className="rounded-xl border border-border bg-background p-4 shadow-sm transition-shadow hover:shadow-md">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold tracking-wide uppercase text-muted-foreground">{label}</p>
        <Icon
          className={`size-4 ${tone === "danger" ? "text-destructive" : tone === "gold" ? "text-gold" : "text-primary"}`}
        />
      </div>
      <p className="mt-2 text-2xl font-extrabold text-primary">{value}</p>
    </div>
  );
}

function AdminDashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ["admin-metrics"],
    queryFn: async (): Promise<Metrics> => {
      const { data, error } = await supabase.rpc("admin_dashboard_metrics");
      if (error) throw error;
      return data as unknown as Metrics;
    },
  });

  return (
    <AdminShell title="Admin Dashboard" description="Live figures calculated from your business data.">
      {isLoading || !data ? (
        <p className="text-sm text-muted-foreground">Loading metrics…</p>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Kpi label="Today's Orders" value={data.todays_orders} icon={ShoppingCart} />
            <Kpi label="Today's Sales" value={formatINR(data.todays_sales)} icon={IndianRupee} tone="gold" />
            <Kpi label="Total Revenue" value={formatINR(data.total_revenue)} icon={IndianRupee} tone="gold" />
            <Kpi label="Pending Orders" value={data.pending_orders} icon={ShoppingCart} />
            <Kpi label="To Dispatch" value={data.to_dispatch} icon={Truck} />
            <Kpi label="Delivered" value={data.delivered_orders} icon={Truck} />
            <Kpi label="Cancelled" value={data.cancelled_orders} icon={PackageX} tone="danger" />
            <Kpi label="Returns / Refunds" value={data.return_requests} icon={PackageX} tone="danger" />
            <Kpi label="Low Stock" value={data.low_stock} icon={PackageX} tone="danger" />
            <Kpi label="Out of Stock" value={data.out_of_stock} icon={PackageX} tone="danger" />
            <Kpi label="New Customers (30d)" value={data.new_customers} icon={Users} />
            <Kpi label="New Reviews" value={data.new_reviews} icon={Star} />
            <Kpi label="Average Rating" value={data.average_rating} icon={Star} tone="gold" />
            <Kpi label="Active Coupons" value={data.active_coupons} icon={TicketPercent} />
            <Kpi label="Areas Not Deliverable" value={data.not_deliverable} icon={Truck} />
            <Kpi label="Open Tickets" value={data.open_tickets} icon={LifeBuoy} />
          </div>

          <div className="mt-8 grid gap-6 lg:grid-cols-3">
            <div className="rounded-xl border border-border bg-background p-5 lg:col-span-2">
              <h2 className="text-sm font-bold tracking-wide uppercase text-primary">Sales by City</h2>
              {data.sales_by_city.length === 0 ? (
                <p className="mt-3 text-sm text-muted-foreground">No orders yet.</p>
              ) : (
                <ul className="mt-4 space-y-3">
                  {data.sales_by_city.map((row) => {
                    const max = Math.max(...data.sales_by_city.map((r) => Number(r.revenue)), 1);
                    return (
                      <li key={row.city}>
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-semibold text-foreground">{row.city}</span>
                          <span className="text-muted-foreground">
                            {row.orders} orders · {formatINR(row.revenue)}
                          </span>
                        </div>
                        <div className="mt-1 h-2 rounded-full bg-muted">
                          <div
                            className="h-2 rounded-full bg-primary"
                            style={{ width: `${(Number(row.revenue) / max) * 100}%` }}
                          />
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>

            <div className="rounded-xl border border-border bg-background p-5">
              <h2 className="text-sm font-bold tracking-wide uppercase text-primary">Quick Actions</h2>
              <div className="mt-4 grid gap-2">
                <Button asChild variant="outline">
                  <Link to="/admin/products">+ Add New Product</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/admin/inventory">Update Inventory</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/admin/coupons">Create Coupon</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/admin/orders">Manage Orders</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/admin/reviews">Moderate Reviews</Link>
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </AdminShell>
  );
}

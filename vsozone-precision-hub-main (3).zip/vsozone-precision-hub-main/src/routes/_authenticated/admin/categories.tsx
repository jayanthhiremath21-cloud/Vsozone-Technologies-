import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Trash2, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AdminShell } from "@/components/admin/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/admin/categories")({
  head: () => ({
    meta: [
      { title: "Category Management — VSOZONE Admin" },
      { name: "description", content: "Create and organise VSOZONE product categories." },
      { property: "og:title", content: "Category Management — VSOZONE Admin" },
      { property: "og:description", content: "Create and organise VSOZONE product categories." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: CategoriesPage,
});

type Category = {
  id: string;
  name: string;
  slug: string;
  parent_id: string | null;
  sort_order: number;
  is_active: boolean;
};

const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

function CategoriesPage() {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [parent, setParent] = useState("");

  const { data: categories = [] } = useQuery({
    queryKey: ["admin-categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories")
        .select("id,name,slug,parent_id,sort_order,is_active")
        .order("sort_order")
        .order("name");
      if (error) throw error;
      return data as Category[];
    },
  });

  const create = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("categories").insert({
        name: name.trim(),
        slug: slugify(name),
        parent_id: parent || null,
        sort_order: categories.length,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setName("");
      setParent("");
      toast.success("Category added");
      void qc.invalidateQueries({ queryKey: ["admin-categories"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const update = useMutation({
    mutationFn: async (patch: Partial<Category> & { id: string }) => {
      const { id, ...rest } = patch;
      const { error } = await supabase.from("categories").update(rest).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin-categories"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("categories").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Category deleted");
      void qc.invalidateQueries({ queryKey: ["admin-categories"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const roots = categories.filter((c) => !c.parent_id);

  return (
    <AdminShell
      area="products"
      title="Category Management"
      description="Categories drive the product catalogue — anything added here is instantly available when creating products."
    >
      <div className="rounded-xl border border-border bg-background p-5">
        <h2 className="text-sm font-bold uppercase tracking-wide text-primary">Add Category</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_1fr_auto]">
          <div>
            <Label htmlFor="cat-name">Name</Label>
            <Input id="cat-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Weighing Scales" />
          </div>
          <div>
            <Label htmlFor="cat-parent">Parent (optional)</Label>
            <select
              id="cat-parent"
              className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
              value={parent}
              onChange={(e) => setParent(e.target.value)}
            >
              <option value="">Top level</option>
              {roots.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <Button disabled={!name.trim() || create.isPending} onClick={() => create.mutate()}>
              <Plus className="size-4" /> Add
            </Button>
          </div>
        </div>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xl border border-border bg-background">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Slug</th>
              <th className="px-4 py-3">Order</th>
              <th className="px-4 py-3">Active</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id} className="border-t border-border">
                <td className="px-4 py-3 font-semibold">
                  {c.parent_id ? <span className="text-muted-foreground">— </span> : null}
                  {c.name}
                </td>
                <td className="px-4 py-3 text-muted-foreground">{c.slug}</td>
                <td className="px-4 py-3">
                  <Input
                    type="number"
                    className="h-8 w-20"
                    defaultValue={c.sort_order}
                    onBlur={(e) => update.mutate({ id: c.id, sort_order: Number(e.target.value) || 0 })}
                  />
                </td>
                <td className="px-4 py-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => update.mutate({ id: c.id, is_active: !c.is_active })}
                  >
                    {c.is_active ? "Active" : "Hidden"}
                  </Button>
                </td>
                <td className="px-4 py-3 text-right">
                  <Button variant="ghost" size="sm" onClick={() => remove.mutate(c.id)}>
                    <Trash2 className="size-4 text-destructive" />
                  </Button>
                </td>
              </tr>
            ))}
            {categories.length === 0 ? (
              <tr>
                <td className="px-4 py-6 text-muted-foreground" colSpan={5}>
                  No categories yet.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ShieldCheck, ShieldOff, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { CrmShell } from "@/components/crm/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserAvatar } from "@/components/site/user-avatar";
import { useIsAdmin } from "@/hooks/use-auth";
import type { AdminCustomer, AdminRecord } from "@/lib/crm";

export const Route = createFileRoute("/_authenticated/customers")({
  head: () => ({
    meta: [
      { title: "Customer Details — VSOZONE Admin" },
      { name: "description", content: "Administrator view of VSOZONE registered customers." },
      { property: "og:title", content: "Customer Details — VSOZONE Admin" },
      { property: "og:description", content: "Administrator view of VSOZONE registered customers." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: CustomersPage,
});

type SortKey = "newest" | "oldest" | "name";
type FilterKey = "all" | "email" | "google" | "admins";

function fmtDate(value: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function CustomersPage() {
  const { data: isAdmin, isLoading: roleLoading } = useIsAdmin();

  if (roleLoading) {
    return (
      <CrmShell title="Customer Details">
        <p className="text-sm text-muted-foreground">Checking permissions…</p>
      </CrmShell>
    );
  }

  if (!isAdmin) {
    return (
      <CrmShell title="Restricted Area" description="Administrator access only.">
        <div className="max-w-md rounded-xl border border-destructive/30 bg-destructive/5 p-6">
          <ShieldOff className="size-6 text-destructive" />
          <h2 className="mt-3 font-semibold text-primary">You don't have access</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Customer records are restricted to VSOZONE administrators. This page and the underlying
            data are protected on the server.
          </p>
        </div>
      </CrmShell>
    );
  }

  return <AdminView />;
}

function AdminView() {
  const queryClient = useQueryClient();
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<SortKey>("newest");
  const [filter, setFilter] = useState<FilterKey>("all");
  const [selected, setSelected] = useState<AdminCustomer | null>(null);
  const [newAdminEmail, setNewAdminEmail] = useState("");

  const customers = useQuery({
    queryKey: ["admin-customers"],
    queryFn: async (): Promise<AdminCustomer[]> => {
      const { data, error } = await supabase.rpc("admin_list_customers");
      if (error) throw error;
      return (data ?? []) as AdminCustomer[];
    },
  });

  const admins = useQuery({
    queryKey: ["admin-list"],
    queryFn: async (): Promise<AdminRecord[]> => {
      const { data, error } = await supabase.rpc("admin_list_admins");
      if (error) throw error;
      return (data ?? []) as AdminRecord[];
    },
  });

  const addAdmin = useMutation({
    mutationFn: async (email: string) => {
      const { error } = await supabase.rpc("admin_add_admin_email", { _email: email });
      if (error) throw error;
    },
    onSuccess: () => {
      setNewAdminEmail("");
      toast.success("Administrator added.");
      queryClient.invalidateQueries({ queryKey: ["admin-list"] });
      queryClient.invalidateQueries({ queryKey: ["admin-customers"] });
    },
    onError: (e: unknown) => toast.error(e instanceof Error ? e.message : "Could not add admin."),
  });

  const removeAdmin = useMutation({
    mutationFn: async (email: string) => {
      const { error } = await supabase.rpc("admin_remove_admin_email", { _email: email });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Administrator removed.");
      queryClient.invalidateQueries({ queryKey: ["admin-list"] });
      queryClient.invalidateQueries({ queryKey: ["admin-customers"] });
    },
    onError: (e: unknown) => toast.error(e instanceof Error ? e.message : "Could not remove admin."),
  });

  const rows = useMemo(() => {
    const list = (customers.data ?? []).filter((c) => {
      if (filter === "google" && c.auth_provider !== "google") return false;
      if (filter === "email" && c.auth_provider === "google") return false;
      if (filter === "admins" && !c.is_admin) return false;
      const term = q.trim().toLowerCase();
      if (!term) return true;
      return [c.full_name, c.display_name, c.username, c.email]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(term));
    });
    return list.sort((a, b) => {
      if (sort === "name")
        return (a.full_name ?? a.display_name ?? "").localeCompare(b.full_name ?? b.display_name ?? "");
      const da = new Date(a.created_at).getTime();
      const db = new Date(b.created_at).getTime();
      return sort === "newest" ? db - da : da - db;
    });
  }, [customers.data, q, sort, filter]);

  const total = customers.data?.length ?? 0;
  const last30 = (customers.data ?? []).filter(
    (c) => Date.now() - new Date(c.created_at).getTime() < 30 * 24 * 3600 * 1000,
  ).length;
  const googleCount = (customers.data ?? []).filter((c) => c.auth_provider === "google").length;

  return (
    <CrmShell
      title="Customer Details"
      description="Registered VSOZONE customers and administrator management."
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Total customers" value={total} />
        <Stat label="New (last 30 days)" value={last30} />
        <Stat label="Google sign-ins" value={googleCount} />
        <Stat label="Administrators" value={admins.data?.length ?? 0} />
      </div>

      <div className="mt-8 rounded-xl border border-border bg-background">
        <div className="flex flex-wrap items-center gap-3 border-b border-border p-4">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search name, username or email…"
            className="max-w-xs"
            aria-label="Search customers"
          />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as FilterKey)}
            aria-label="Filter customers"
            className="h-9 rounded-md border border-input bg-card px-3 text-sm"
          >
            <option value="all">All customers</option>
            <option value="email">Email sign-up</option>
            <option value="google">Google sign-up</option>
            <option value="admins">Administrators</option>
          </select>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            aria-label="Sort customers"
            className="h-9 rounded-md border border-input bg-card px-3 text-sm"
          >
            <option value="newest">Newest first</option>
            <option value="oldest">Oldest first</option>
            <option value="name">Name (A–Z)</option>
          </select>
          <span className="ml-auto text-xs text-muted-foreground">{rows.length} shown</span>
        </div>

        {customers.isLoading ? (
          <p className="p-6 text-sm text-muted-foreground">Loading customers…</p>
        ) : customers.error ? (
          <p className="p-6 text-sm text-destructive">
            {customers.error instanceof Error ? customers.error.message : "Could not load customers."}
          </p>
        ) : rows.length === 0 ? (
          <p className="p-6 text-sm text-muted-foreground">No customers match your filters.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[54rem] text-left text-sm">
              <thead className="bg-muted/40 text-xs tracking-wide text-muted-foreground uppercase">
                <tr>
                  <th className="px-4 py-3 font-semibold">Customer</th>
                  <th className="px-4 py-3 font-semibold">Username</th>
                  <th className="px-4 py-3 font-semibold">Email</th>
                  <th className="px-4 py-3 font-semibold">Method</th>
                  <th className="px-4 py-3 font-semibold">Joined</th>
                  <th className="px-4 py-3 font-semibold">Last sign-in</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {rows.map((c) => (
                  <tr key={c.id} className="border-t border-border/70 hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <UserAvatar src={c.avatar_url} name={c.full_name ?? c.display_name} className="size-8" />
                        <span className="font-medium text-foreground">
                          {c.full_name || c.display_name || "—"}
                          {c.is_admin ? (
                            <span className="ml-2 rounded-full border border-gold/50 bg-gold/10 px-2 py-0.5 text-[0.6rem] font-bold tracking-wide text-primary uppercase">
                              Admin
                            </span>
                          ) : null}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">@{c.username ?? "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground">{c.email ?? "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground capitalize">
                      {c.auth_provider === "google" ? "Google" : "Email"}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{fmtDate(c.created_at)}</td>
                    <td className="px-4 py-3 text-muted-foreground">{fmtDate(c.last_sign_in_at)}</td>
                    <td className="px-4 py-3 text-right">
                      <Button size="sm" variant="outline" onClick={() => setSelected(c)}>
                        View
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {selected ? (
        <div className="mt-6 rounded-xl border border-gold/30 bg-background p-5 lg:p-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <UserAvatar
                src={selected.avatar_url}
                name={selected.full_name ?? selected.display_name}
                className="size-14 text-base"
              />
              <div>
                <h2 className="font-semibold text-primary">
                  {selected.full_name || selected.display_name || "Customer"}
                </h2>
                <p className="text-xs text-muted-foreground">@{selected.username ?? "—"}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setSelected(null)}>
              Close
            </Button>
          </div>
          <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-3">
            <Detail label="Email" value={selected.email ?? "—"} />
            <Detail label="Email confirmed" value={selected.email_confirmed ? "Yes" : "No"} />
            <Detail
              label="Authentication"
              value={selected.auth_provider === "google" ? "Google" : "Email & password"}
            />
            <Detail label="Signed up" value={fmtDate(selected.created_at)} />
            <Detail label="Last sign-in" value={fmtDate(selected.last_sign_in_at)} />
            <Detail label="Role" value={selected.is_admin ? "Administrator" : "Customer"} />
          </dl>
        </div>
      ) : null}

      <div id="manage-admins" className="mt-8 scroll-mt-24 rounded-xl border border-border bg-background p-5 lg:p-6">
        <div className="flex items-center gap-2">
          <ShieldCheck className="size-5 text-gold" />
          <h2 className="font-semibold text-primary">Manage Administrators</h2>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          Administrators can view customer records and manage other administrators.
        </p>

        <form
          className="mt-4 flex flex-wrap items-end gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            const email = newAdminEmail.trim().toLowerCase();
            if (email) addAdmin.mutate(email);
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="admin_email">Administrator email</Label>
            <Input
              id="admin_email"
              type="email"
              value={newAdminEmail}
              onChange={(e) => setNewAdminEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-72 max-w-full"
            />
          </div>
          <Button type="submit" disabled={addAdmin.isPending}>
            {addAdmin.isPending ? "Adding…" : "Add administrator"}
          </Button>
        </form>

        <ul className="mt-5 divide-y divide-border rounded-lg border border-border">
          {(admins.data ?? []).map((a) => (
            <li key={a.email} className="flex flex-wrap items-center gap-3 px-4 py-3 text-sm">
              <Users className="size-4 text-muted-foreground" />
              <span className="font-medium text-foreground">{a.email}</span>
              <span className="text-xs text-muted-foreground">
                {a.is_registered ? "Registered" : "Invited — not signed up yet"}
              </span>
              <Button
                size="sm"
                variant="outline"
                className="ml-auto"
                disabled={removeAdmin.isPending}
                onClick={() => removeAdmin.mutate(a.email)}
              >
                Remove
              </Button>
            </li>
          ))}
          {admins.data?.length === 0 ? (
            <li className="px-4 py-3 text-sm text-muted-foreground">No administrators listed.</li>
          ) : null}
        </ul>
      </div>
    </CrmShell>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl border border-border bg-background p-5">
      <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">{label}</p>
      <p className="mt-2 text-3xl font-extrabold text-primary">{value}</p>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">{label}</dt>
      <dd className="mt-1 text-foreground">{value}</dd>
    </div>
  );
}

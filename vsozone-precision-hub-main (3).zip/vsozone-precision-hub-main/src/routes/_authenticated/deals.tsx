import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { toast } from "sonner";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { CrmShell } from "@/components/crm/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DEAL_STAGES, formatINR, stageTone, type Contact, type Deal, type DealStage } from "@/lib/crm";

export const Route = createFileRoute("/_authenticated/deals")({
  head: () => ({
    meta: [
      { title: "Deals — VSOZONE CRM" },
      { name: "description", content: "Track and move your VSOZONE CRM deals through the pipeline." },
      { property: "og:title", content: "Deals — VSOZONE CRM" },
      { property: "og:description", content: "Create, filter and progress your sales deals." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: DealsPage,
});

const dealSchema = z.object({
  title: z.string().trim().min(1, "Title is required").max(160),
  company: z.string().trim().max(120).optional(),
  value: z.coerce.number().min(0, "Value must be positive").max(1_000_000_000),
  stage: z.enum(DEAL_STAGES),
  contact_id: z.string().optional(),
  expected_close_date: z.string().optional(),
  notes: z.string().trim().max(2000).optional(),
});

type FormValues = z.input<typeof dealSchema>;
const empty: FormValues = {
  title: "",
  company: "",
  value: 0,
  stage: "New Lead",
  contact_id: "",
  expected_close_date: "",
  notes: "",
};

function DealsPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [stageFilter, setStageFilter] = useState<"all" | DealStage>("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Deal | null>(null);
  const [form, setForm] = useState<FormValues>(empty);
  const [error, setError] = useState<string | null>(null);
  const [toDelete, setToDelete] = useState<Deal | null>(null);

  const { data: deals = [], isLoading } = useQuery({
    queryKey: ["deals"],
    queryFn: async () => {
      const { data, error: err } = await supabase.from("deals").select("*").order("created_at", { ascending: false });
      if (err) throw err;
      return data as Deal[];
    },
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts"],
    queryFn: async () => {
      const { data, error: err } = await supabase.from("contacts").select("*").order("name");
      if (err) throw err;
      return data as Contact[];
    },
  });

  const logActivity = async (action: string, id: string | null, description: string) => {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;
    await supabase
      .from("activity_log")
      .insert({ user_id: userData.user.id, action, entity_type: "deal", entity_id: id, description });
  };

  const save = useMutation({
    mutationFn: async (values: z.output<typeof dealSchema>) => {
      const payload = {
        title: values.title,
        company: values.company || null,
        value: values.value,
        stage: values.stage,
        contact_id: values.contact_id || null,
        expected_close_date: values.expected_close_date || null,
        notes: values.notes || null,
      };
      if (editing) {
        const { error: err } = await supabase.from("deals").update(payload).eq("id", editing.id);
        if (err) throw err;
        await logActivity(
          editing.stage !== values.stage ? "Deal Stage Changed" : "Deal Updated",
          editing.id,
          `${values.title} → ${values.stage}`,
        );
        return;
      }
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Not signed in");
      const { data: row, error: err } = await supabase
        .from("deals")
        .insert({ ...payload, user_id: userData.user.id })
        .select("id")
        .single();
      if (err) throw err;
      await logActivity("Deal Created", row.id, `Created deal ${values.title}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["deals"] });
      toast.success(editing ? "Deal updated" : "Deal created");
      setOpen(false);
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save deal"),
  });

  const changeStage = useMutation({
    mutationFn: async ({ deal, stage }: { deal: Deal; stage: DealStage }) => {
      const { error: err } = await supabase.from("deals").update({ stage }).eq("id", deal.id);
      if (err) throw err;
      await logActivity("Deal Stage Changed", deal.id, `${deal.title} → ${stage}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["deals"] });
      toast.success("Stage updated");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not update stage"),
  });

  const remove = useMutation({
    mutationFn: async (deal: Deal) => {
      const { error: err } = await supabase.from("deals").delete().eq("id", deal.id);
      if (err) throw err;
      await logActivity("Deal Deleted", deal.id, `Deleted deal ${deal.title}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["deals"] });
      toast.success("Deal deleted");
      setToDelete(null);
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not delete deal"),
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return deals.filter((d) => {
      const matchesStage = stageFilter === "all" || d.stage === stageFilter;
      const matchesQuery =
        !q || [d.title, d.company, d.notes].some((v) => v?.toLowerCase().includes(q));
      return matchesStage && matchesQuery;
    });
  }, [deals, search, stageFilter]);

  function openNew() {
    setEditing(null);
    setForm(empty);
    setError(null);
    setOpen(true);
  }

  function openEdit(d: Deal) {
    setEditing(d);
    setForm({
      title: d.title,
      company: d.company ?? "",
      value: Number(d.value ?? 0),
      stage: d.stage,
      contact_id: d.contact_id ?? "",
      expected_close_date: d.expected_close_date ?? "",
      notes: d.notes ?? "",
    });
    setError(null);
    setOpen(true);
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = dealSchema.safeParse(form);
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Invalid input");
      return;
    }
    setError(null);
    save.mutate(parsed.data);
  }

  return (
    <CrmShell
      title="Deals"
      description="Your pipeline — only you can see these deals."
      actions={
        <Button onClick={openNew}>
          <Plus className="size-4" /> Add Deal
        </Button>
      }
    >
      <div className="flex flex-wrap gap-3">
        <Input
          placeholder="Search deals…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm bg-background"
        />
        <Select value={stageFilter} onValueChange={(v) => setStageFilter(v as "all" | DealStage)}>
          <SelectTrigger className="w-52 bg-background">
            <SelectValue placeholder="All stages" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All stages</SelectItem>
            {DEAL_STAGES.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {isLoading ? (
          <p className="text-muted-foreground">Loading…</p>
        ) : filtered.length === 0 ? (
          <p className="text-muted-foreground">No deals found.</p>
        ) : (
          filtered.map((d) => (
            <article key={d.id} className="rounded-lg border border-border bg-background p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-bold text-foreground">{d.title}</h3>
                  <p className="text-sm text-muted-foreground">{d.company ?? "—"}</p>
                </div>
                <span className={`rounded-full border px-2.5 py-1 text-xs font-semibold ${stageTone(d.stage)}`}>
                  {d.stage}
                </span>
              </div>
              <p className="mt-3 text-xl font-extrabold text-primary">{formatINR(d.value)}</p>
              {d.expected_close_date ? (
                <p className="mt-1 text-xs text-muted-foreground">Expected close: {d.expected_close_date}</p>
              ) : null}
              <div className="mt-4 flex items-center gap-2">
                <Select value={d.stage} onValueChange={(v) => changeStage.mutate({ deal: d, stage: v as DealStage })}>
                  <SelectTrigger className="h-9 flex-1 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DEAL_STAGES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {s}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="ghost" size="icon" aria-label="Edit deal" onClick={() => openEdit(d)}>
                  <Pencil className="size-4" />
                </Button>
                <Button variant="ghost" size="icon" aria-label="Delete deal" onClick={() => setToDelete(d)}>
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </div>
            </article>
          ))
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Deal" : "Add Deal"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={submit} className="space-y-3">
            <FormRow label="Title">
              <Input value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} maxLength={160} />
            </FormRow>
            <FormRow label="Company">
              <Input value={form.company ?? ""} onChange={(e) => setForm((f) => ({ ...f, company: e.target.value }))} maxLength={120} />
            </FormRow>
            <FormRow label="Value (₹)">
              <Input
                type="number"
                min={0}
                value={String(form.value ?? 0)}
                onChange={(e) => setForm((f) => ({ ...f, value: e.target.value === "" ? 0 : Number(e.target.value) }))}
              />
            </FormRow>
            <FormRow label="Stage">
              <Select value={form.stage} onValueChange={(v) => setForm((f) => ({ ...f, stage: v as DealStage }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DEAL_STAGES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormRow>
            <FormRow label="Linked Contact (optional)">
              <Select
                value={form.contact_id || "none"}
                onValueChange={(v) => setForm((f) => ({ ...f, contact_id: v === "none" ? "" : v }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="No contact" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No contact</SelectItem>
                  {contacts.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormRow>
            <FormRow label="Expected Close Date">
              <Input
                type="date"
                value={form.expected_close_date ?? ""}
                onChange={(e) => setForm((f) => ({ ...f, expected_close_date: e.target.value }))}
              />
            </FormRow>
            <FormRow label="Notes">
              <Textarea
                rows={3}
                value={form.notes ?? ""}
                onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                maxLength={2000}
              />
            </FormRow>
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <DialogFooter>
              <Button type="submit" disabled={save.isPending}>
                {save.isPending ? "Saving…" : "Save Deal"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(toDelete)} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this deal?</AlertDialogTitle>
            <AlertDialogDescription>{toDelete?.title} will be permanently removed.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => toDelete && remove.mutate(toDelete)}>Confirm</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </CrmShell>
  );
}

function FormRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-semibold uppercase text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

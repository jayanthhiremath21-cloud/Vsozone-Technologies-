import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { toast } from "sonner";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { CrmShell } from "@/components/crm/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { Contact } from "@/lib/crm";

export const Route = createFileRoute("/_authenticated/contacts")({
  head: () => ({
    meta: [
      { title: "Contacts — VSOZONE CRM" },
      { name: "description", content: "Manage your VSOZONE CRM contacts." },
      { property: "og:title", content: "Contacts — VSOZONE CRM" },
      { property: "og:description", content: "Add, search and edit your CRM contacts." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ContactsPage,
});

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(120),
  company: z.string().trim().max(120).optional(),
  email: z.union([z.literal(""), z.string().trim().email("Invalid email").max(255)]).optional(),
  phone: z.string().trim().max(40).optional(),
  location: z.string().trim().max(120).optional(),
  notes: z.string().trim().max(2000).optional(),
});

type FormValues = z.infer<typeof contactSchema>;
const empty: FormValues = { name: "", company: "", email: "", phone: "", location: "", notes: "" };

function ContactsPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Contact | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<FormValues>(empty);
  const [error, setError] = useState<string | null>(null);
  const [toDelete, setToDelete] = useState<Contact | null>(null);

  const { data: contacts = [], isLoading } = useQuery({
    queryKey: ["contacts"],
    queryFn: async () => {
      const { data, error: err } = await supabase
        .from("contacts")
        .select("*")
        .order("created_at", { ascending: false });
      if (err) throw err;
      return data as Contact[];
    },
  });

  const logActivity = async (action: string, id: string | null, description: string) => {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;
    await supabase
      .from("activity_log")
      .insert({ user_id: userData.user.id, action, entity_type: "contact", entity_id: id, description });
  };

  const save = useMutation({
    mutationFn: async (values: FormValues) => {
      const payload = {
        name: values.name,
        company: values.company || null,
        email: values.email || null,
        phone: values.phone || null,
        location: values.location || null,
        notes: values.notes || null,
      };
      if (editing) {
        const { error: err } = await supabase.from("contacts").update(payload).eq("id", editing.id);
        if (err) throw err;
        await logActivity("Contact Updated", editing.id, `Updated contact ${payload.name}`);
        return;
      }
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Not signed in");
      const { data: row, error: err } = await supabase
        .from("contacts")
        .insert({ ...payload, user_id: userData.user.id })
        .select("id")
        .single();
      if (err) throw err;
      await logActivity("Contact Created", row.id, `Created contact ${payload.name}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      toast.success(editing ? "Contact updated" : "Contact added");
      setOpen(false);
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not save contact"),
  });

  const remove = useMutation({
    mutationFn: async (contact: Contact) => {
      const { error: err } = await supabase.from("contacts").delete().eq("id", contact.id);
      if (err) throw err;
      await logActivity("Contact Deleted", contact.id, `Deleted contact ${contact.name}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      queryClient.invalidateQueries({ queryKey: ["deals"] });
      toast.success("Contact deleted");
      setToDelete(null);
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not delete contact"),
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return contacts;
    return contacts.filter((c) =>
      [c.name, c.company, c.email, c.phone, c.location].some((v) => v?.toLowerCase().includes(q)),
    );
  }, [contacts, search]);

  function openNew() {
    setEditing(null);
    setForm(empty);
    setError(null);
    setOpen(true);
  }

  function openEdit(c: Contact) {
    setEditing(c);
    setForm({
      name: c.name,
      company: c.company ?? "",
      email: c.email ?? "",
      phone: c.phone ?? "",
      location: c.location ?? "",
      notes: c.notes ?? "",
    });
    setError(null);
    setOpen(true);
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = contactSchema.safeParse(form);
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Invalid input");
      return;
    }
    setError(null);
    save.mutate(parsed.data);
  }

  return (
    <CrmShell
      title="Contacts"
      description="Your private contact book — visible only to you."
      actions={
        <Button onClick={openNew}>
          <Plus className="size-4" /> Add Contact
        </Button>
      }
    >
      <Input
        placeholder="Search contacts by name, company, phone or location…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="max-w-md bg-background"
      />

      <div className="mt-6 overflow-hidden rounded-lg border border-border bg-background">
        <table className="w-full text-sm">
          <thead className="bg-muted/60 text-left text-xs font-bold uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="hidden px-4 py-3 sm:table-cell">Company</th>
              <th className="hidden px-4 py-3 md:table-cell">Phone</th>
              <th className="hidden px-4 py-3 lg:table-cell">Location</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {isLoading ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">
                  Loading…
                </td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">
                  No contacts found.
                </td>
              </tr>
            ) : (
              filtered.map((c) => (
                <tr key={c.id} className="hover:bg-muted/40">
                  <td className="px-4 py-3">
                    <p className="font-semibold text-foreground">{c.name}</p>
                    <p className="text-xs text-muted-foreground">{c.email ?? ""}</p>
                  </td>
                  <td className="hidden px-4 py-3 sm:table-cell">{c.company ?? "—"}</td>
                  <td className="hidden px-4 py-3 md:table-cell">{c.phone ?? "—"}</td>
                  <td className="hidden px-4 py-3 lg:table-cell">{c.location ?? "—"}</td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <Button variant="ghost" size="icon" aria-label="Edit contact" onClick={() => openEdit(c)}>
                      <Pencil className="size-4" />
                    </Button>
                    <Button variant="ghost" size="icon" aria-label="Delete contact" onClick={() => setToDelete(c)}>
                      <Trash2 className="size-4 text-destructive" />
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Contact" : "Add Contact"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={submit} className="space-y-3">
            {(
              [
                ["name", "Name"],
                ["company", "Company"],
                ["email", "Email"],
                ["phone", "Phone"],
                ["location", "Location"],
              ] as const
            ).map(([key, label]) => (
              <div key={key} className="space-y-1.5">
                <Label className="text-xs font-semibold uppercase text-muted-foreground">{label}</Label>
                <Input
                  value={form[key] ?? ""}
                  onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                  maxLength={255}
                />
              </div>
            ))}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold uppercase text-muted-foreground">Notes</Label>
              <Textarea
                value={form.notes ?? ""}
                onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                maxLength={2000}
                rows={3}
              />
            </div>
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <DialogFooter>
              <Button type="submit" disabled={save.isPending}>
                {save.isPending ? "Saving…" : "Save Contact"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(toDelete)} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this contact?</AlertDialogTitle>
            <AlertDialogDescription>
              {toDelete?.name} will be permanently removed from your CRM.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => toDelete && remove.mutate(toDelete)}>Confirm</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </CrmShell>
  );
}

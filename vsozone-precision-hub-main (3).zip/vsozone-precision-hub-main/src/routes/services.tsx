import { createFileRoute } from "@tanstack/react-router";
import { COMPANY, services, serviceRegions } from "@/lib/site-data";
import { Section, SectionHead, ServiceJourney, EnquiryCta } from "@/components/site/pieces";
import { Reveal } from "@/components/site/reveal";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Installation, Commissioning, AMC & Repair | VSOZONE" },
      {
        name: "description",
        content:
          "Installation, commissioning, calibration support, automation, AMC, maintenance, repair and genuine spare parts across Karnataka, Goa and Maharashtra.",
      },
      { property: "og:title", content: "VSOZONE Services — Installation, AMC, Maintenance, Repair" },
      {
        property: "og:description",
        content: "A complete service ecosystem from consultation to long-term maintenance.",
      },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <>
      <Section tone="muted">
        <SectionHead
          eyebrow="Service Ecosystem"
          title="Support that starts before purchase and continues for years"
          subtitle="Our engineers handle the full lifecycle so your weighing, cash and security systems stay accurate and available."
        />
        <ServiceJourney />

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => (
            <Reveal key={s.name} delay={i * 40}>
              <article className="card-lift h-full rounded-xl border border-border bg-card p-6">
                <h3 className="text-base font-bold text-primary">{s.name}</h3>
                <div aria-hidden className="mt-3 rule-gold opacity-70" />
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{s.description}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHead
          eyebrow="Regional Network"
          title="Service coverage across North Karnataka and beyond"
          subtitle={`Headquartered in ${COMPANY.city}, with service reach into neighbouring states.`}
        />
        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          <div className="rounded-xl border border-border bg-card p-6">
            <h3 className="text-sm font-bold uppercase tracking-[0.16em] text-gold">Karnataka</h3>
            <div className="mt-5 flex flex-wrap gap-2">
              {serviceRegions.karnataka.map((city) => (
                <span
                  key={city}
                  className="rounded-md border border-border px-3 py-1.5 text-sm font-medium text-foreground/80"
                >
                  {city}
                </span>
              ))}
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card p-6">
            <h3 className="text-sm font-bold uppercase tracking-[0.16em] text-gold">Beyond Karnataka</h3>
            <div className="mt-5 flex flex-wrap gap-2">
              {serviceRegions.beyond.map((state) => (
                <span
                  key={state}
                  className="rounded-md border border-border px-3 py-1.5 text-sm font-medium text-foreground/80"
                >
                  {state}
                </span>
              ))}
            </div>
          </div>
        </div>
      </Section>
      <EnquiryCta />
    </>
  );
}

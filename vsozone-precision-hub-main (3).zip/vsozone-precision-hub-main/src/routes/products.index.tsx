import { createFileRoute, Link } from "@tanstack/react-router";
import { categories, products } from "@/lib/site-data";
import { ProductCard, Section, SectionHead, EnquiryCta } from "@/components/site/pieces";

export const Route = createFileRoute("/products/")({
  validateSearch: (search: Record<string, unknown>): { category?: string } =>
    typeof search["category"] === "string" ? { category: search["category"] as string } : {},
  head: () => ({
    meta: [
      { title: "Products — Weighing, Weighbridges, Cash & Security | VSOZONE" },
      {
        name: "description",
        content:
          "Browse VSOZONE weighing machines, electronic weighbridges, cash counting and billing machines, CCTV and safety lockers.",
      },
      { property: "og:title", content: "VSOZONE Products — Weighing, Weighbridges, Cash, Security" },
      {
        property: "og:description",
        content: "Precision weighing, cash handling, billing and security equipment with full service support.",
      },
    ],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  const { category } = Route.useSearch();
  const filtered = category ? products.filter((p) => p.categorySlug === category) : products;

  return (
    <>
      <Section tone="muted">
        <SectionHead
          eyebrow="Product Catalogue"
          title="Engineered products for measurement, cash handling and security"
          subtitle="Filter by category to find the right capacity and configuration for your operation."
        />
        <div className="mt-8 flex flex-wrap gap-2">
          <Link
            to="/products"
            search={{}}
            className={`rounded-md border px-4 py-2 text-sm font-semibold transition-colors ${
              category ? "border-border bg-card text-foreground/75" : "border-gold bg-gold/12 text-primary"
            }`}
          >
            All Products
          </Link>
          {categories.map((c) => (
            <Link
              key={c.slug}
              to="/products"
              search={{ category: c.slug }}
              className={`rounded-md border px-4 py-2 text-sm font-semibold transition-colors ${
                category === c.slug
                  ? "border-gold bg-gold/12 text-primary"
                  : "border-border bg-card text-foreground/75 hover:border-gold/50 hover:text-primary"
              }`}
            >
              {c.title}
            </Link>
          ))}
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p, i) => (
            <ProductCard key={p.slug} product={p} delay={i * 40} />
          ))}
        </div>
      </Section>
      <EnquiryCta />
    </>
  );
}

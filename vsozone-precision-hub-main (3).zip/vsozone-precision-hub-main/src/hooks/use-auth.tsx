import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Profile } from "@/lib/crm";

export function useSession() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  return { session, user: session?.user ?? null, loading };
}

export function useProfile(enabled = true) {
  return useQuery({
    queryKey: ["profile"],
    enabled,
    queryFn: async (): Promise<Profile | null> => {
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) return null;
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", auth.user.id)
        .maybeSingle();
      if (error) throw error;
      return data as Profile | null;
    },
  });
}

export function useIsAdmin(enabled = true) {
  return useQuery({
    queryKey: ["is-admin"],
    enabled,
    queryFn: async () => {
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) return false;
      const { data, error } = await supabase.rpc("has_role", {
        _user_id: auth.user.id,
        _role: "admin",
      });
      if (error) throw error;
      return Boolean(data);
    },
  });
}

export type StaffRole =
  | "super_admin"
  | "product_manager"
  | "order_manager"
  | "crm_manager"
  | "marketing_manager"
  | "support_manager";

/** Server-verified staff role (null for normal customers). */
export function useStaffRole(enabled = true) {
  return useQuery({
    queryKey: ["staff-role"],
    enabled,
    queryFn: async (): Promise<StaffRole | null> => {
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) return null;
      const { data, error } = await supabase.rpc("staff_role_of", { _user_id: auth.user.id });
      if (error) throw error;
      return (data as StaffRole | null) ?? null;
    },
  });
}

const AREA_MAP: Record<StaffRole, string[]> = {
  super_admin: ["products", "orders", "crm", "reviews", "marketing", "support", "staff", "settings"],
  product_manager: ["products"],
  order_manager: ["orders", "products"],
  crm_manager: ["crm", "reviews"],
  marketing_manager: ["marketing"],
  support_manager: ["support", "orders"],
};

export function canAccessArea(role: StaffRole | null | undefined, area: string) {
  if (!role) return false;
  return AREA_MAP[role].includes(area);
}

/** Combined helper for header/sidebar */
export function useAuth() {
  const { session, user, loading } = useSession();
  const profile = useProfile(Boolean(user));
  const isAdmin = useIsAdmin(Boolean(user));
  const staff = useStaffRole(Boolean(user));
  return {
    session,
    user,
    loading,
    profile: profile.data ?? null,
    profileLoading: profile.isLoading,
    isAdmin: isAdmin.data ?? false,
    staffRole: staff.data ?? null,
    isStaff: Boolean(staff.data),
    staffLoading: staff.isLoading,
  };
}


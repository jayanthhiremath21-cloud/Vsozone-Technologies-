import heroIndustrial from "@/assets/hero-industrial.jpg";
import prodJewellery from "@/assets/prod-jewellery.jpg";
import prodPlatform from "@/assets/prod-platform.jpg";
import prodCash from "@/assets/prod-cash.jpg";
import sceneSecurity from "@/assets/scene-security.jpg";
import sceneIndustry from "@/assets/scene-industry.jpg";
import sceneJewellery from "@/assets/scene-jewellery.jpg";

export const COMPANY = {
  brand: "VSOZONE Technologies",
  legalName: "V.S. Ozone Technologies",
  tagline: "Where Accuracy Meets Quality",
  phone: "9972607605",
  phoneHref: "tel:+919972607605",
  whatsappHref: "https://wa.me/919972607605",
  instagram: "https://www.instagram.com/vsozone__technologies/",
  established: 2002,
  address: [
    "Plot No. 199, Ground Floor, Venkatesh,",
    "Zafarabad Shaik Roza,",
    "Opp. Agriculture College, Aland Road,",
    "Kalaburagi, Karnataka – 585103",
  ],
  city: "Kalaburagi, Karnataka",
};

export const images = {
  heroIndustrial,
  prodJewellery,
  prodPlatform,
  prodCash,
  sceneSecurity,
  sceneIndustry,
  sceneJewellery,
};

export type Category = {
  slug: string;
  index: string;
  title: string;
  blurb: string;
  items: string[];
  note?: string;
  image: string;
  cta: string;
};

export const categories: Category[] = [
  {
    slug: "weighing-machines",
    index: "01",
    title: "Weighing Machines",
    blurb:
      "Precision electronic weighing across jewellery, retail, commercial and industrial applications.",
    items: [
      "Jewellery Weighing Machines",
      "Candy Scales",
      "Table Top Scales",
      "Personal & Baby Scales",
      "Roller Platform Scales",
      "Platform Scales",
      "Heavy Platform Scales",
    ],
    image: prodPlatform,
    cta: "Explore Weighing Solutions",
  },
  {
    slug: "weighbridges",
    index: "02",
    title: "Weighbridges",
    blurb:
      "Electronic weighbridge infrastructure engineered for continuous heavy-duty vehicle weighing.",
    items: [
      "Electronic Weighbridges",
      "Heavy-Duty Weighbridges",
      "Industrial Weighing Systems",
      "High-Capacity Weighing Infrastructure",
    ],
    note: "Capacity range: 10 Tons – 500 Tons (company-provided specification)",
    image: heroIndustrial,
    cta: "Explore Weighbridges",
  },
  {
    slug: "cash-billing",
    index: "03",
    title: "Cash Counting & Billing",
    blurb: "Cash handling and billing technology for banking, retail and commercial counters.",
    items: [
      "Cash Counting Machines",
      "Currency Counting Solutions",
      "Fake Note Detection",
      "Billing Machines",
      "POS Solutions",
    ],
    image: prodCash,
    cta: "Explore Cash & Billing",
  },
  {
    slug: "security",
    index: "04",
    title: "Security Solutions",
    blurb: "Surveillance and physical security systems for premises, stores and industrial sites.",
    items: ["CCTV Cameras", "Surveillance Systems", "Safety Lockers", "Security Systems"],
    image: sceneSecurity,
    cta: "Explore Security",
  },
  {
    slug: "automation-services",
    index: "05",
    title: "Automation & Services",
    blurb: "End-to-end engineering support from commissioning to long-term maintenance.",
    items: [
      "Installation",
      "Commissioning",
      "Automation",
      "AMC",
      "Maintenance",
      "Repair",
      "Spare Parts",
    ],
    image: sceneIndustry,
    cta: "Explore Services",
  },
];

export type Product = {
  slug: string;
  name: string;
  category: string;
  categorySlug: string;
  short: string;
  capacity: string;
  accuracy?: string;
  construction?: string;
  display?: string;
  application: string;
  image: string;
  features: string[];
  industries: string[];
};

const CONTACT_SPEC = "Contact us for detailed specifications";

export const products: Product[] = [
  {
    slug: "jewellery-model-vte",
    name: "Jewellery Model — VTE",
    category: "Weighing Machines",
    categorySlug: "weighing-machines",
    short:
      "High-precision jewellery weighing machine built for fine-resolution measurement at the counter.",
    capacity: "300 g × 0.01 g  |  600 g × 0.01 g",
    accuracy: "0.01 g readability",
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Jewellery retail, gold and silver weighing, precision measurement",
    image: prodJewellery,
    features: [
      "Fine 0.01 g resolution",
      "Compact counter footprint",
      "Stable readings for small samples",
      "Installation and service support available",
    ],
    industries: ["Jewellery", "Retail", "Commercial Businesses"],
  },
  {
    slug: "candy-scale",
    name: "Candy Scale",
    category: "Weighing Machines",
    categorySlug: "weighing-machines",
    short: "Compact counter scale for confectionery, provisions and light retail weighing.",
    capacity: "5 kg – 20 kg",
    accuracy: CONTACT_SPEC,
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Sweet shops, provision stores, retail counters",
    image: prodJewellery,
    features: [
      "Everyday retail counter use",
      "Clear digital readout",
      "Easy to operate",
      "Service and spare parts support",
    ],
    industries: ["Retail", "Commercial Businesses"],
  },
  {
    slug: "table-top-scale",
    name: "Table Top Scale",
    category: "Weighing Machines",
    categorySlug: "weighing-machines",
    short: "Versatile table top weighing scale for commercial and light industrial counters.",
    capacity: "10 kg – 35 kg",
    accuracy: CONTACT_SPEC,
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Retail, packaging, small-batch weighing",
    image: prodPlatform,
    features: [
      "Robust everyday construction",
      "Suited to continuous counter use",
      "Multiple capacity options",
      "AMC available",
    ],
    industries: ["Retail", "Warehousing", "Commercial Businesses"],
  },
  {
    slug: "personal-baby-scale",
    name: "Personal + Baby Scale",
    category: "Weighing Machines",
    categorySlug: "weighing-machines",
    short: "Personal and baby weighing scale for clinics, pharmacies and health counters.",
    capacity: "100 kg – 150 kg",
    accuracy: CONTACT_SPEC,
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Clinics, pharmacies, health and wellness counters",
    image: prodPlatform,
    features: [
      "Dual personal and baby weighing",
      "Stable low-profile platform",
      "Clear readout",
      "Service support available",
    ],
    industries: ["Retail", "Commercial Businesses"],
  },
  {
    slug: "roller-platform",
    name: "Roller Platform Scale",
    category: "Weighing Machines",
    categorySlug: "weighing-machines",
    short: "Roller-top platform scale for line weighing of cartons and packaged goods.",
    capacity: "200 kg – 500 kg",
    accuracy: CONTACT_SPEC,
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Warehousing, dispatch lines, logistics handling",
    image: prodPlatform,
    features: [
      "Roller top for easy load transfer",
      "Built for dispatch throughput",
      "Heavy-use construction",
      "Installation and commissioning support",
    ],
    industries: ["Logistics", "Warehousing", "Manufacturing"],
  },
  {
    slug: "platform-ch",
    name: "Platform Scale — CH",
    category: "Weighing Machines",
    categorySlug: "weighing-machines",
    short: "Chequered-plate platform scale for general commercial and industrial weighing.",
    capacity: "200 kg – 300 kg",
    accuracy: CONTACT_SPEC,
    construction: "Chequered plate platform",
    display: CONTACT_SPEC,
    application: "Godowns, workshops, commercial weighing",
    image: prodPlatform,
    features: [
      "Chequered plate deck",
      "Indicator pole mounting",
      "Suited to daily industrial use",
      "AMC and repair support",
    ],
    industries: ["Manufacturing", "Warehousing", "Agriculture"],
  },
  {
    slug: "platform-ss",
    name: "Platform Scale — SS",
    category: "Weighing Machines",
    categorySlug: "weighing-machines",
    short: "Stainless steel platform scale for hygiene-sensitive and corrosion-prone environments.",
    capacity: "100 kg – 200 kg",
    accuracy: CONTACT_SPEC,
    construction: "Stainless steel platform",
    display: CONTACT_SPEC,
    application: "Food handling, processing units, clean environments",
    image: prodPlatform,
    features: [
      "Stainless steel deck",
      "Easy to clean",
      "Corrosion-resistant build",
      "Service support available",
    ],
    industries: ["Manufacturing", "Retail", "Warehousing"],
  },
  {
    slug: "heavy-platform-ch",
    name: "Heavy Platform — CH",
    category: "Weighing Machines",
    categorySlug: "weighing-machines",
    short: "Heavy-duty chequered platform scale for high-load industrial weighing.",
    capacity: "1000 kg – 2000 kg",
    accuracy: CONTACT_SPEC,
    construction: "Heavy chequered plate platform",
    display: CONTACT_SPEC,
    application: "Factories, heavy goods handling, industrial operations",
    image: prodPlatform,
    features: [
      "High load capacity",
      "Reinforced structure",
      "Continuous-duty operation",
      "Installation, AMC and spares",
    ],
    industries: ["Manufacturing", "Logistics", "Industrial Operations"],
  },
  {
    slug: "electronic-weighbridge",
    name: "Electronic Weighbridge",
    category: "Weighbridges",
    categorySlug: "weighbridges",
    short:
      "Electronic weighbridge systems for vehicle and bulk material weighing at industrial sites.",
    capacity: "10 Tons – 500 Tons (company-provided range)",
    accuracy: CONTACT_SPEC,
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Factories, mines, logistics yards, agricultural markets",
    image: heroIndustrial,
    features: [
      "Vehicle and bulk material weighing",
      "Heavy-duty structural design",
      "Site survey, installation and commissioning",
      "AMC, maintenance and spare parts",
    ],
    industries: ["Manufacturing", "Logistics", "Agriculture", "Industrial Operations"],
  },
  {
    slug: "cash-counting-machine",
    name: "Cash Counting Machine",
    category: "Cash Counting & Billing",
    categorySlug: "cash-billing",
    short: "Currency counting machines with fake note detection for high-volume cash counters.",
    capacity: CONTACT_SPEC,
    accuracy: CONTACT_SPEC,
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Banking, retail cash counters, commercial cash rooms",
    image: prodCash,
    features: [
      "High-speed note counting",
      "Fake note detection options",
      "Batch and add modes",
      "Service and spare parts support",
    ],
    industries: ["Banking", "Retail", "Commercial Businesses"],
  },
  {
    slug: "billing-machine",
    name: "Billing Machine & POS",
    category: "Cash Counting & Billing",
    categorySlug: "cash-billing",
    short: "Billing machines and POS solutions for retail and commercial counters.",
    capacity: CONTACT_SPEC,
    accuracy: CONTACT_SPEC,
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Retail billing, commercial counters, point-of-sale operations",
    image: prodCash,
    features: [
      "Counter billing and printing",
      "POS integration options",
      "Weighing scale integration where applicable",
      "Installation and support",
    ],
    industries: ["Retail", "Commercial Businesses"],
  },
  {
    slug: "cctv-surveillance",
    name: "CCTV & Surveillance Systems",
    category: "Security Solutions",
    categorySlug: "security",
    short: "CCTV cameras and surveillance systems for premises monitoring and site security.",
    capacity: CONTACT_SPEC,
    accuracy: CONTACT_SPEC,
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Factories, warehouses, retail stores, offices, jewellery showrooms",
    image: sceneSecurity,
    features: [
      "Camera selection and site planning",
      "Recording and monitoring setup",
      "Installation and commissioning",
      "Maintenance and AMC",
    ],
    industries: ["Retail", "Manufacturing", "Banking", "Commercial Businesses"],
  },
  {
    slug: "safety-lockers",
    name: "Safety Lockers",
    category: "Security Solutions",
    categorySlug: "security",
    short: "Safety lockers and secure storage for cash, documents and valuables.",
    capacity: CONTACT_SPEC,
    accuracy: CONTACT_SPEC,
    construction: CONTACT_SPEC,
    display: CONTACT_SPEC,
    application: "Jewellery stores, offices, banking and cash operations",
    image: sceneSecurity,
    features: [
      "Secure storage for valuables",
      "Multiple size options",
      "Delivery and installation",
      "Service support",
    ],
    industries: ["Jewellery", "Banking", "Commercial Businesses"],
  },
];

export const industries = [
  {
    name: "Jewellery",
    description: "High-precision weighing solutions for gold, silver and gemstone counters.",
    image: sceneJewellery,
  },
  {
    name: "Manufacturing",
    description: "Precision weighing for production, batching and dispatch operations.",
    image: sceneIndustry,
  },
  {
    name: "Logistics",
    description: "Reliable vehicle and material weighing across transport operations.",
    image: heroIndustrial,
  },
  {
    name: "Transportation",
    description: "Weighbridge infrastructure for fleet and load verification.",
    image: heroIndustrial,
  },
  {
    name: "Agriculture",
    description: "Robust weighing for produce, feed and agricultural market yards.",
    image: sceneIndustry,
  },
  {
    name: "Retail",
    description: "Accurate commercial weighing, billing and counter technology.",
    image: sceneJewellery,
  },
  {
    name: "Warehousing",
    description: "Dependable weighing infrastructure for inbound and outbound flows.",
    image: sceneIndustry,
  },
  {
    name: "Banking",
    description: "Cash counting, fake note detection and security systems.",
    image: sceneSecurity,
  },
  {
    name: "Commercial Businesses",
    description: "Integrated weighing, billing and security technology.",
    image: prodCash,
  },
  {
    name: "Construction",
    description: "Heavy material weighing for site and yard operations.",
    image: heroIndustrial,
  },
  {
    name: "Industrial Operations",
    description: "High-capacity weighing systems for continuous industrial duty.",
    image: sceneIndustry,
  },
];

export const services = [
  { name: "Installation", description: "On-site installation by trained service personnel." },
  { name: "Commissioning", description: "System setup, verification and handover." },
  { name: "Calibration Support", description: "Support for calibration and accuracy checks." },
  { name: "Automation", description: "Automation of weighing and business processes." },
  { name: "AMC", description: "Annual maintenance contracts for uninterrupted operation." },
  { name: "Maintenance", description: "Scheduled and preventive maintenance visits." },
  { name: "Repair", description: "Breakdown repair support for installed equipment." },
  { name: "Spare Parts", description: "Genuine spare parts and replacement components." },
];

export const serviceJourney = [
  "Consultation",
  "Selection",
  "Installation",
  "Commissioning",
  "Training",
  "AMC",
  "Maintenance",
  "Repair",
];

export const serviceRegions = {
  karnataka: [
    "Kalaburagi",
    "Bidar",
    "Yadgir",
    "Vijayapura",
    "Bagalkot",
    "Ballari",
    "Raichur",
    "Mangaluru",
    "Karwar",
  ],
  beyond: ["Goa", "Maharashtra"],
};

export const whyVsozone = [
  { title: "Precision", description: "Solutions designed around accurate measurement." },
  { title: "Reliability", description: "Equipment designed for dependable everyday operation." },
  { title: "Engineering", description: "Technology backed by practical engineering expertise." },
  {
    title: "Complete Solutions",
    description: "Products, installation, commissioning and support.",
  },
  { title: "Service", description: "AMC, maintenance, repairs and spare parts." },
  { title: "Long-Term Partnership", description: "Support beyond the initial purchase." },
];

export const timeline = [
  { label: "2002", title: "Company established", description: "V.S. Ozone Technologies begins operations in Kalaburagi, Karnataka." },
  { label: "Growth", title: "Weighing & industrial solutions", description: "Expansion into commercial and industrial weighing systems." },
  { label: "Technology", title: "Cash, billing & security", description: "Cash counting, billing and security solutions added to the portfolio." },
  { label: "Service", title: "Support network", description: "Installation, AMC, maintenance and spare-parts support expanded." },
  { label: "Today", title: "Engineering & technology portfolio", description: "A broader engineering and technology solutions portfolio." },
];

export const WHATSAPP_TEMPLATE = `Welcome to VSOZONE Technologies!
Thank you for contacting us.

We specialize in:
• Electronic Weighbridges
• Electronic Weighing Machines
• Jewellery Weighing Machines
• Cash Counting & Billing Machines
• Safety Lockers & Security Systems
• Installation, Commissioning & Automation
• AMC, Maintenance & Repair Services
• Spare Parts

Please share:
Your Name
Location
Your Requirement

Our team will contact you shortly with the best solution.`;

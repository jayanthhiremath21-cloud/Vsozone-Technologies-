import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { buildVedSystemPrompt } from "./ved.server";

const askVedSchema = z.object({
  message: z.string().min(1).max(1000),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().max(4000),
      }),
    )
    .max(12)
    .optional(),
});

export const askVed = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => askVedSchema.parse(data))
  .handler(async ({ data }) => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) {
      return {
        message:
          "VED is not available right now. Please reach us on WhatsApp at 9972607605 and our team will help you straight away.",
      };
    }

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: buildVedSystemPrompt() },
          ...(data.history ?? []),
          { role: "user", content: data.message },
        ],
      }),
    });

    if (!res.ok) {
      return {
        message:
          "VED could not respond just now. Please try again, or contact us on WhatsApp at 9972607605.",
      };
    }

    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const content = json.choices?.[0]?.message?.content?.trim();
    return {
      message:
        content ||
        "I did not catch that. Could you rephrase, or tell me which product you are looking for?",
    };
  });

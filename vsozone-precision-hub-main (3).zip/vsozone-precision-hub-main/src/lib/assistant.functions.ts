import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { DEAL_STAGES } from "@/lib/crm";

const stageEnum = z.enum(DEAL_STAGES);

export const crmActionSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("create_contact"),
    name: z.string().min(1).max(120),
    company: z.string().max(120).nullish(),
    email: z.string().max(255).nullish(),
    phone: z.string().max(40).nullish(),
    location: z.string().max(120).nullish(),
    notes: z.string().max(2000).nullish(),
  }),
  z.object({
    type: z.literal("update_contact"),
    id: z.string().uuid(),
    name: z.string().min(1).max(120).nullish(),
    company: z.string().max(120).nullish(),
    email: z.string().max(255).nullish(),
    phone: z.string().max(40).nullish(),
    location: z.string().max(120).nullish(),
    notes: z.string().max(2000).nullish(),
  }),
  z.object({ type: z.literal("delete_contact"), id: z.string().uuid() }),
  z.object({
    type: z.literal("create_deal"),
    title: z.string().min(1).max(160),
    company: z.string().max(120).nullish(),
    value: z.number().nonnegative().max(1_000_000_000).nullish(),
    stage: stageEnum.nullish(),
    contact_id: z.string().uuid().nullish(),
    expected_close_date: z.string().max(20).nullish(),
    notes: z.string().max(2000).nullish(),
  }),
  z.object({
    type: z.literal("update_deal"),
    id: z.string().uuid(),
    title: z.string().min(1).max(160).nullish(),
    company: z.string().max(120).nullish(),
    value: z.number().nonnegative().max(1_000_000_000).nullish(),
    stage: stageEnum.nullish(),
    expected_close_date: z.string().max(20).nullish(),
    notes: z.string().max(2000).nullish(),
  }),
  z.object({ type: z.literal("delete_deal"), id: z.string().uuid() }),
]);

export type CrmAction = z.infer<typeof crmActionSchema>;

export type AssistantResult =
  | { kind: "message"; message: string }
  | { kind: "proposal"; message: string; summary: string[]; action: CrmAction };

const SYSTEM_PROMPT = `You are the VSOZONE Technologies CRM assistant. You turn plain English into structured CRM actions for the signed-in user only.

Return ONLY strict JSON, no markdown fences, matching one of:
1. {"kind":"message","message":"..."} — for questions, answers, clarification requests, or when required info is missing.
2. {"kind":"proposal","message":"short confirmation sentence","summary":["Field: value", ...],"action":{...}}

Action shapes:
- {"type":"create_contact","name":"","company":null,"email":null,"phone":null,"location":null,"notes":null}
- {"type":"update_contact","id":"<existing contact uuid>", ...fields to change}
- {"type":"delete_contact","id":"<uuid>"}
- {"type":"create_deal","title":"","company":null,"value":0,"stage":"New Lead","contact_id":null,"expected_close_date":null,"notes":null}
- {"type":"update_deal","id":"<uuid>", ...fields to change (stage moves use "stage")}
- {"type":"delete_deal","id":"<uuid>"}

Valid stages: ${DEAL_STAGES.join(", ")}.

Rules:
- Only use uuids that appear in the provided CRM data. Never invent ids.
- If multiple records match, ask which one (kind "message"), listing the options.
- If a required field is missing (contact name, deal title or deal value), ask for it instead of guessing.
- Indian money words: "1.5 lakh" = 150000, "2 crore" = 20000000.
- For questions like "show my open deals" or "find contacts from Kalaburagi", answer from the provided data with kind "message".
- Never perform anything outside these CRM actions.`;

function fmtAmount(v: unknown) {
  const n = Number(v ?? 0);
  return Number.isFinite(n) ? n.toLocaleString("en-IN") : "0";
}

export const askAssistant = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { message: string; history?: { role: "user" | "assistant"; content: string }[] }) =>
    z
      .object({
        message: z.string().trim().min(1).max(1000),
        history: z
          .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(2000) }))
          .max(12)
          .optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<AssistantResult> => {
    const { supabase } = context;

    const [{ data: contacts }, { data: deals }] = await Promise.all([
      supabase.from("contacts").select("id,name,company,email,phone,location").limit(200),
      supabase.from("deals").select("id,title,company,value,stage,contact_id").limit(200),
    ]);

    const crmContext = `CONTACTS:\n${JSON.stringify(contacts ?? [])}\n\nDEALS:\n${JSON.stringify(deals ?? [])}`;

    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) return { kind: "message", message: "The AI assistant is not configured right now." };

    let response: Response;
    try {
      response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "google/gemini-3.5-flash",
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            { role: "system", content: crmContext },
            ...(data.history ?? []),
            { role: "user", content: data.message },
          ],
        }),
      });
    } catch {
      return { kind: "message", message: "I couldn't reach the AI service. Please try again." };
    }

    if (response.status === 429)
      return { kind: "message", message: "Too many requests right now — please try again in a moment." };
    if (response.status === 402)
      return { kind: "message", message: "AI credits are exhausted. Please top up to keep using the assistant." };
    if (!response.ok) {
      console.error("AI gateway error", response.status, await response.text());
      return { kind: "message", message: "The AI service returned an error. Please try again." };
    }

    const payload = (await response.json()) as { choices?: { message?: { content?: string } }[] };
    const raw = payload.choices?.[0]?.message?.content?.trim() ?? "";
    const cleaned = raw.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();

    let parsed: unknown;
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      return { kind: "message", message: raw || "Sorry, I didn't understand that. Could you rephrase?" };
    }

    const shape = z.object({
      kind: z.enum(["message", "proposal"]),
      message: z.string().max(2000).optional(),
      summary: z.array(z.string().max(200)).max(12).optional(),
      action: z.unknown().optional(),
    });
    const base = shape.safeParse(parsed);
    if (!base.success) return { kind: "message", message: "Sorry, I didn't understand that. Could you rephrase?" };

    if (base.data.kind === "message" || !base.data.action) {
      return { kind: "message", message: base.data.message ?? "How can I help with your contacts or deals?" };
    }

    const action = crmActionSchema.safeParse(base.data.action);
    if (!action.success) {
      return { kind: "message", message: base.data.message ?? "I need a bit more detail to do that." };
    }

    return {
      kind: "proposal",
      message: base.data.message ?? "Please confirm this action.",
      summary: base.data.summary ?? [],
      action: action.data,
    };
  });

export const runCrmAction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => crmActionSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const log = async (action: string, entity_type: string, entity_id: string | null, description: string) => {
      await supabase.from("activity_log").insert({ user_id: userId, action, entity_type, entity_id, description });
    };

    const clean = <T extends Record<string, unknown>>(obj: T) =>
      Object.fromEntries(Object.entries(obj).filter(([, v]) => v !== undefined && v !== null));

    switch (data.type) {
      case "create_contact": {
        const { type: _t, ...fields } = data;
        const { data: row, error } = await supabase
          .from("contacts")
          .insert({ ...clean(fields), name: data.name, user_id: userId } as never)
          .select("id,name")
          .single();
        if (error) throw new Error(error.message);
        await log("Contact Created", "contact", row.id, `Created contact ${row.name}`);
        return { message: `✓ Contact "${row.name}" added successfully.` };
      }
      case "update_contact": {
        const { type: _t, id, ...fields } = data;
        const { data: row, error } = await supabase
          .from("contacts")
          .update(clean(fields) as never)
          .eq("id", id)
          .select("id,name")
          .single();
        if (error) throw new Error(error.message);
        await log("Contact Updated", "contact", row.id, `Updated contact ${row.name}`);
        return { message: `✓ Contact "${row.name}" updated successfully.` };
      }
      case "delete_contact": {
        const { data: row, error } = await supabase
          .from("contacts")
          .delete()
          .eq("id", data.id)
          .select("id,name")
          .single();
        if (error) throw new Error(error.message);
        await log("Contact Deleted", "contact", row.id, `Deleted contact ${row.name}`);
        return { message: `✓ Contact "${row.name}" deleted.` };
      }
      case "create_deal": {
        const { type: _t, ...fields } = data;
        const { data: row, error } = await supabase
          .from("deals")
          .insert({
            ...clean(fields),
            title: data.title,
            value: data.value ?? 0,
            stage: data.stage ?? "New Lead",
            user_id: userId,
          } as never)
          .select("id,title,value")
          .single();
        if (error) throw new Error(error.message);
        await log("Deal Created", "deal", row.id, `Created deal ${row.title} (₹${fmtAmount(row.value)})`);
        return { message: `✓ Deal "${row.title}" created successfully.` };
      }
      case "update_deal": {
        const { type: _t, id, ...fields } = data;
        const { data: row, error } = await supabase
          .from("deals")
          .update(clean(fields) as never)
          .eq("id", id)
          .select("id,title,stage")
          .single();
        if (error) throw new Error(error.message);
        await log(
          fields.stage ? "Deal Stage Changed" : "Deal Updated",
          "deal",
          row.id,
          `${row.title} → ${row.stage}`,
        );
        return { message: `✓ Deal "${row.title}" updated successfully.` };
      }
      case "delete_deal": {
        const { data: row, error } = await supabase
          .from("deals")
          .delete()
          .eq("id", data.id)
          .select("id,title")
          .single();
        if (error) throw new Error(error.message);
        await log("Deal Deleted", "deal", row.id, `Deleted deal ${row.title}`);
        return { message: `✓ Deal "${row.title}" deleted.` };
      }
    }
  });

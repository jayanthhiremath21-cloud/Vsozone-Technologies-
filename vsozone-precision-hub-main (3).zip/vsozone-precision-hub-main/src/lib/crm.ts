export const DEAL_STAGES = [
  "New Lead",
  "Contacted",
  "Qualified",
  "Proposal",
  "Negotiation",
  "Won",
  "Lost",
] as const;

export type DealStage = (typeof DEAL_STAGES)[number];

export const OPEN_STAGES: DealStage[] = [
  "New Lead",
  "Contacted",
  "Qualified",
  "Proposal",
  "Negotiation",
];

export type Contact = {
  id: string;
  user_id: string;
  name: string;
  company: string | null;
  email: string | null;
  phone: string | null;
  location: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
};

export type Deal = {
  id: string;
  user_id: string;
  contact_id: string | null;
  title: string;
  company: string | null;
  value: number | string;
  stage: DealStage;
  expected_close_date: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
};

export type Profile = {
  id: string;
  email: string | null;
  display_name: string | null;
  username: string | null;
  full_name: string | null;
  avatar_url: string | null;
  auth_provider: string;
  created_at: string;
  updated_at: string;
};

export type AdminCustomer = {
  id: string;
  email: string | null;
  full_name: string | null;
  display_name: string | null;
  username: string | null;
  avatar_url: string | null;
  auth_provider: string | null;
  created_at: string;
  last_sign_in_at: string | null;
  email_confirmed: boolean;
  is_admin: boolean;
};

export type AdminRecord = {
  email: string;
  created_at: string;
  is_registered: boolean;
};

export type ActivityEntry = {
  id: string;
  user_id: string;
  action: string;
  entity_type: string;
  entity_id: string | null;
  description: string | null;
  created_at: string;
};

export function formatINR(value: number | string | null | undefined) {
  const n = typeof value === "string" ? Number(value) : (value ?? 0);
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number.isFinite(n) ? n : 0);
}

export function stageTone(stage: DealStage) {
  if (stage === "Won") return "border-gold/60 bg-gold/15 text-primary";
  if (stage === "Lost") return "border-destructive/30 bg-destructive/10 text-destructive";
  return "border-primary/25 bg-primary/8 text-primary";
}

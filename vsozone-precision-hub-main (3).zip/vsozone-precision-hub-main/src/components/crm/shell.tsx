import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Users,
  Briefcase,
  Sparkles,
  UserCircle,
  LogOut,
  ShieldCheck,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useAuth, canAccessArea } from "@/hooks/use-auth";

const links = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/contacts", label: "Contacts", icon: Users },
  { to: "/deals", label: "Deals", icon: Briefcase },
  { to: "/assistant", label: "AI Assistant", icon: Sparkles },
  { to: "/profile", label: "Profile", icon: UserCircle },
] as const;

export function CrmShell({
  title,
  description,
  actions,
  children,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
}) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { staffRole, staffLoading, loading } = useAuth();
  const allowed = canAccessArea(staffRole, "crm");

  useEffect(() => {
    if (loading || staffLoading) return;
    if (!allowed) navigate({ to: "/profile", replace: true });
  }, [allowed, loading, staffLoading, navigate]);

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  if (loading || staffLoading) {
    return <div className="p-10 text-sm text-muted-foreground">Checking permissions…</div>;
  }
  if (!allowed) {
    return <div className="p-10 text-sm text-muted-foreground">Access denied.</div>;
  }

  return (
    <div className="bg-muted/30 min-h-screen">
      <div className="border-b border-border bg-background">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-2 px-4 py-3 lg:px-6">
          <span className="mr-2 text-xs font-bold tracking-[0.2em] uppercase text-gold">CRM</span>
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-semibold text-foreground/70 transition-colors hover:bg-primary/5 hover:text-primary"
              activeProps={{ className: "bg-primary/10 text-primary" }}
            >
              <l.icon className="size-4" />
              {l.label}
            </Link>
          ))}
          <Link
            to="/customers"
            className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-semibold text-foreground/70 transition-colors hover:bg-primary/5 hover:text-primary"
            activeProps={{ className: "bg-primary/10 text-primary" }}
          >
            <ShieldCheck className="size-4" />
            Customer Details
          </Link>
          <Link
            to="/admin"
            className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-semibold text-foreground/70 transition-colors hover:bg-primary/5 hover:text-primary"
          >
            <ShieldCheck className="size-4" />
            Admin
          </Link>
          <Button variant="ghost" size="sm" className="ml-auto" onClick={signOut}>
            <LogOut className="size-4" /> Logout
          </Button>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8 lg:px-6 lg:py-10">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-primary lg:text-3xl">{title}</h1>
            {description ? <p className="mt-1 text-sm text-muted-foreground">{description}</p> : null}
            <div aria-hidden className="mt-3 rule-gold" />
          </div>
          {actions}
        </div>
        <div className="mt-8 pb-20 lg:pb-8">{children}</div>
      </div>
    </div>
  );
}

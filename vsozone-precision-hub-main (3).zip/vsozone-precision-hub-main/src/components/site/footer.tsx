import { Link } from "@tanstack/react-router";
import { Instagram, MessageCircle, Phone } from "lucide-react";
import { COMPANY } from "@/lib/site-data";
import { Wordmark } from "./logo";

const productLinks = [
  { label: "Weighing Machines", slug: "platform-ch" },
  { label: "Weighbridges", slug: "electronic-weighbridge" },
  { label: "Cash Counting Machines", slug: "cash-counting-machine" },
  { label: "Billing Machines", slug: "billing-machine" },
  { label: "CCTV", slug: "cctv-surveillance" },
  { label: "Safety Lockers", slug: "safety-lockers" },
] as const;

const columns = [
  {
    heading: "Solutions",
    links: [
      { label: "Industrial Weighing", to: "/solutions" },
      { label: "Commercial Weighing", to: "/solutions" },
      { label: "Security", to: "/solutions" },
      { label: "Automation", to: "/solutions" },
      { label: "Business Solutions", to: "/solutions" },
    ],
  },
  {
    heading: "Services",
    links: [
      { label: "Installation", to: "/services" },
      { label: "Commissioning", to: "/services" },
      { label: "AMC", to: "/services" },
      { label: "Maintenance", to: "/services" },
      { label: "Repair", to: "/services" },
      { label: "Spare Parts", to: "/services" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "About Us", to: "/about" },
      { label: "Founder", to: "/about" },
      { label: "Industries", to: "/industries" },
      { label: "Service Network", to: "/services" },
      { label: "Contact", to: "/contact" },
    ],
  },
] as const;

export function Footer() {
  return (
    <footer className="relative overflow-hidden surface-deep">
      <div aria-hidden className="pointer-events-none absolute inset-0 grid-tech opacity-40" />
      <div className="relative mx-auto max-w-7xl px-4 pt-16 pb-28 lg:px-6 lg:pb-16">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_3fr]">
          <div>
            <div className="rounded-lg bg-deep-foreground/5 p-4 ring-1 ring-gold/20 inline-block">
              <Wordmark tone="light" />
            </div>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-deep-foreground/70">
              {COMPANY.legalName} — an Indian engineering and technology company based in{" "}
              {COMPANY.city}, delivering weighing, cash-handling, security, billing and automation
              solutions.
            </p>
            <address className="mt-5 space-y-0.5 text-sm not-italic text-deep-foreground/70">
              {COMPANY.address.map((line) => (
                <div key={line}>{line}</div>
              ))}
            </address>
            <div className="mt-5 flex flex-wrap gap-3">
              <a
                href={COMPANY.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-md bg-gold px-4 py-2 text-sm font-semibold text-gold-foreground transition-transform duration-300 hover:-translate-y-0.5"
              >
                <MessageCircle className="size-4" /> WhatsApp
              </a>
              <a
                href={COMPANY.phoneHref}
                className="inline-flex items-center gap-2 rounded-md border border-deep-foreground/25 px-4 py-2 text-sm font-semibold text-deep-foreground transition-colors hover:border-gold hover:text-gold"
              >
                <Phone className="size-4" /> {COMPANY.phone}
              </a>
              <a
                href={COMPANY.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="VSOZONE Technologies on Instagram"
                className="inline-flex items-center gap-2 rounded-md border border-deep-foreground/25 px-4 py-2 text-sm font-semibold text-deep-foreground transition-colors hover:border-gold hover:text-gold"
              >
                <Instagram className="size-4" /> Instagram
              </a>
            </div>
          </div>

          <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-[0.16em] text-gold">Products</h3>
              <div aria-hidden className="mt-3 rule-gold opacity-60" />
              <ul className="mt-4 space-y-2.5">
                {productLinks.map((link) => (
                  <li key={link.label}>
                    <Link
                      to="/products/$slug"
                      params={{ slug: link.slug }}
                      className="text-sm text-deep-foreground/70 transition-colors hover:text-gold"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            {columns.map((col) => (
              <div key={col.heading}>
                <h3 className="text-sm font-bold uppercase tracking-[0.16em] text-gold">
                  {col.heading}
                </h3>
                <div aria-hidden className="mt-3 rule-gold opacity-60" />
                <ul className="mt-4 space-y-2.5">
                  {col.links.map((link) => (
                    <li key={link.label}>
                      <Link
                        to={link.to}
                        className="text-sm text-deep-foreground/70 transition-colors hover:text-gold"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-2 border-t border-deep-foreground/15 pt-6 text-sm text-deep-foreground/60 sm:flex-row sm:items-center sm:justify-between">
          <p>© {COMPANY.brand}. All Rights Reserved.</p>
          <p className="font-semibold text-gold">“{COMPANY.tagline}”</p>
        </div>
      </div>
    </footer>
  );
}

import { useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { categories, industries, products, services } from "@/lib/site-data";

export function SearchDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (value: boolean) => void;
}) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  const suggestions = useMemo(
    () => ["Weighbridge", "Jewellery scale", "Platform scale", "Cash counting", "CCTV", "AMC"],
    [],
  );

  function go(to: string) {
    onOpenChange(false);
    setQuery("");
    void navigate({ to });
  }

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput
        value={query}
        onValueChange={setQuery}
        placeholder="Search weighing machines, weighbridges, CCTV, cash counters..."
      />
      <CommandList>
        <CommandEmpty>No matches found. Try “weighbridge” or “CCTV”.</CommandEmpty>
        {query.length === 0 ? (
          <CommandGroup heading="Suggestions">
            {suggestions.map((s) => (
              <CommandItem key={s} value={s} onSelect={() => setQuery(s)}>
                <Search className="text-gold" />
                {s}
              </CommandItem>
            ))}
          </CommandGroup>
        ) : null}
        <CommandGroup heading="Products">
          {products.map((p) => (
            <CommandItem
              key={p.slug}
              value={`${p.name} ${p.category} ${p.capacity}`}
              onSelect={() => go(`/products/${p.slug}`)}
            >
              <span className="font-medium">{p.name}</span>
              <span className="ml-auto text-xs text-muted-foreground">{p.category}</span>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="Solutions">
          {categories.map((c) => (
            <CommandItem key={c.slug} value={c.title} onSelect={() => go("/solutions")}>
              {c.title}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="Services">
          {services.map((s) => (
            <CommandItem key={s.name} value={s.name} onSelect={() => go("/services")}>
              {s.name}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="Industries">
          {industries.map((i) => (
            <CommandItem key={i.name} value={i.name} onSelect={() => go("/industries")}>
              {i.name}
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}

import { Link } from "@tanstack/react-router";
import { Home, MessageCircle, Package, Phone, Mail } from "lucide-react";
import { COMPANY, WHATSAPP_TEMPLATE } from "@/lib/site-data";
import { VedWidget } from "@/components/site/ved-widget";

const whatsappLink = `${COMPANY.whatsappHref}?text=${encodeURIComponent(WHATSAPP_TEMPLATE)}`;

export function FloatingActions() {
  return (
    <>
      <div className="fixed right-4 bottom-24 z-40 flex flex-col items-end gap-3 lg:bottom-6">
        <a
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="group inline-flex items-center gap-2 rounded-full bg-primary py-3 pr-5 pl-4 text-sm font-semibold text-primary-foreground shadow-[0_18px_40px_-18px_oklch(0.245_0.05_168/0.8)] transition-all duration-300 hover:bg-gold hover:text-gold-foreground"
        >
          <MessageCircle className="size-5" />
          <span className="hidden sm:inline">WhatsApp Us</span>
        </a>
        <VedWidget />
      </div>

      <nav
        aria-label="Quick actions"
        className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-gold/20 surface-deep lg:hidden"
      >
        <BottomItem to="/" icon={<Home className="size-5" />} label="Home" exact />
        <BottomItem to="/products" icon={<Package className="size-5" />} label="Products" />
        <a
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center gap-1 py-2.5 text-[0.65rem] font-semibold text-gold"
        >
          <MessageCircle className="size-5" />
          WhatsApp
        </a>
        <a
          href={COMPANY.phoneHref}
          className="flex flex-col items-center justify-center gap-1 py-2.5 text-[0.65rem] font-semibold text-deep-foreground/75"
        >
          <Phone className="size-5" />
          Call Now
        </a>
        <BottomItem to="/contact" icon={<Mail className="size-5" />} label="Contact" />
      </nav>
    </>
  );
}

function BottomItem({
  to,
  icon,
  label,
  exact,
}: {
  to: string;
  icon: React.ReactNode;
  label: string;
  exact?: boolean;
}) {
  return (
    <Link
      to={to}
      activeOptions={{ exact: Boolean(exact) }}
      className="flex flex-col items-center justify-center gap-1 py-2.5 text-[0.65rem] font-semibold text-deep-foreground/75"
      activeProps={{ className: "text-gold" }}
    >
      {icon}
      {label}
    </Link>
  );
}

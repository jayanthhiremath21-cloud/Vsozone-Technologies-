import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { COMPANY } from "@/lib/site-data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type EnquiryContextValue = {
  open: (subject?: string) => void;
};

const EnquiryContext = createContext<EnquiryContextValue>({ open: () => {} });

export function useEnquiry() {
  return useContext(EnquiryContext);
}

const schema = z.object({
  name: z.string().trim().min(2, "Please enter your name").max(100),
  company: z.string().trim().max(120).optional().or(z.literal("")),
  phone: z
    .string()
    .trim()
    .min(7, "Please enter a valid phone number")
    .max(20)
    .regex(/^[0-9+\-\s()]+$/, "Phone number can contain digits and + - ( ) only"),
  location: z.string().trim().max(120).optional().or(z.literal("")),
  requirement: z.string().trim().min(2, "Please enter your requirement").max(200),
  message: z.string().trim().max(1000).optional().or(z.literal("")),
});

export function EnquiryProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [subject, setSubject] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const open = useCallback((nextSubject?: string) => {
    setSubject(nextSubject ?? "");
    setErrors({});
    setIsOpen(true);
  }, []);

  const value = useMemo(() => ({ open }), [open]);

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const parsed = schema.safeParse({
      name: String(form.get("name") ?? ""),
      company: String(form.get("company") ?? ""),
      phone: String(form.get("phone") ?? ""),
      location: String(form.get("location") ?? ""),
      requirement: String(form.get("requirement") ?? ""),
      message: String(form.get("message") ?? ""),
    });

    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = String(issue.path[0]);
        if (!next[key]) next[key] = issue.message;
      }
      setErrors(next);
      return;
    }

    const d = parsed.data;
    const text = [
      "New enquiry — VSOZONE Technologies",
      `Name: ${d.name}`,
      d.company ? `Company: ${d.company}` : null,
      `Phone: ${d.phone}`,
      d.location ? `Location: ${d.location}` : null,
      `Requirement: ${d.requirement}`,
      d.message ? `Message: ${d.message}` : null,
    ]
      .filter(Boolean)
      .join("\n");

    window.open(`${COMPANY.whatsappHref}?text=${encodeURIComponent(text)}`, "_blank", "noopener");
    toast.success("Enquiry ready to send", {
      description: "WhatsApp has opened with your enquiry details.",
    });
    setIsOpen(false);
  }

  return (
    <EnquiryContext.Provider value={value}>
      {children}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <p className="eyebrow">Enquiry</p>
            <DialogTitle className="text-2xl">Request a Quote</DialogTitle>
            <DialogDescription>
              Share your requirement and our team will contact you with the right solution.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="grid gap-4" noValidate>
            <Field id="name" label="Name" error={errors["name"]} required />
            <Field id="company" label="Company" error={errors["company"]} />
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="phone" label="Phone Number" type="tel" error={errors["phone"]} required />
              <Field id="location" label="Location" error={errors["location"]} />
            </div>
            <Field
              id="requirement"
              label="Product / Requirement"
              defaultValue={subject}
              error={errors["requirement"]}
              required
            />
            <div className="grid gap-2">
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" name="message" rows={4} maxLength={1000} />
              {errors["message"] ? (
                <p className="text-xs text-destructive">{errors["message"]}</p>
              ) : null}
            </div>
            <Button type="submit" size="lg" className="w-full">
              Send Enquiry
            </Button>
            <p className="text-center text-xs text-muted-foreground">
              Or call / WhatsApp us directly on{" "}
              <a className="font-semibold text-primary hover:underline" href={COMPANY.phoneHref}>
                {COMPANY.phone}
              </a>
            </p>
          </form>
        </DialogContent>
      </Dialog>
    </EnquiryContext.Provider>
  );
}

function Field({
  id,
  label,
  error,
  type = "text",
  required,
  defaultValue,
}: {
  id: string;
  label: string;
  error?: string | undefined;
  type?: string | undefined;
  required?: boolean | undefined;
  defaultValue?: string | undefined;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>
        {label}
        {required ? <span className="ml-1 text-gold">*</span> : null}
      </Label>
      <Input
        id={id}
        name={id}
        type={type}
        maxLength={200}
        defaultValue={defaultValue}
        aria-invalid={Boolean(error)}
      />
      {error ? <p className="text-xs text-destructive">{error}</p> : null}
    </div>
  );
}

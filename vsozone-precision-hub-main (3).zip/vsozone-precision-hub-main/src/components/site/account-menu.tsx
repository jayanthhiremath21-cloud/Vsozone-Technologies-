import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { LogOut, ShieldCheck, UserCircle, LayoutDashboard } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { UserAvatar } from "@/components/site/user-avatar";
import { useAuth } from "@/hooks/use-auth";

export function AccountMenu({ className }: { className?: string }) {
  const { user, loading, profile, isAdmin } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  // After Google sign-in the provider returns to "/" — send the user on to
  // wherever they were heading before they signed in.
  useEffect(() => {
    if (!user) return;
    const target = sessionStorage.getItem("vsozone:after-login");
    if (!target) return;
    sessionStorage.removeItem("vsozone:after-login");
    if (target !== pathname) navigate({ to: target, replace: true });
  }, [user, navigate, pathname]);

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/", replace: true });
  }

  if (loading) return null;

  if (!user) {
    return (
      <Button variant="outline" size="sm" className={className} asChild>
        <Link to="/auth" search={{ redirect: pathname }}>
          <UserCircle className="size-4" /> Login / Sign Up
        </Link>
      </Button>
    );
  }

  const name = profile?.full_name || profile?.display_name || user.email || "Account";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label="Account menu"
          className={`inline-flex items-center gap-2 rounded-full border border-border py-1 pr-3 pl-1 transition-colors hover:border-gold/60 ${className ?? ""}`}
        >
          <UserAvatar src={profile?.avatar_url} name={name} className="size-8" />
          <span className="hidden max-w-[9rem] truncate text-sm font-semibold text-foreground sm:inline">
            {profile?.username ? `@${profile.username}` : name}
          </span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel className="truncate">{name}</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link to="/profile">
            <UserCircle className="size-4" /> Profile
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/dashboard">
            <LayoutDashboard className="size-4" /> My Account
          </Link>
        </DropdownMenuItem>
        {isAdmin ? (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/customers">
                <ShieldCheck className="size-4" /> Customer Details
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/customers" hash="manage-admins">
                <ShieldCheck className="size-4" /> Manage Administrators
              </Link>
            </DropdownMenuItem>
          </>
        ) : null}
        <DropdownMenuSeparator />
        <DropdownMenuItem onSelect={() => void signOut()}>
          <LogOut className="size-4" /> Logout
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

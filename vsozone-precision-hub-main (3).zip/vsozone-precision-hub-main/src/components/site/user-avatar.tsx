import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { initialsOf, resolveAvatarUrl } from "@/lib/avatar";

export function UserAvatar({
  src,
  name,
  className,
}: {
  src?: string | null | undefined;
  name?: string | null | undefined;
  className?: string | undefined;
}) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setUrl(null);
    resolveAvatarUrl(src).then((u) => {
      if (active) setUrl(u);
    });
    return () => {
      active = false;
    };
  }, [src]);

  return (
    <span
      className={cn(
        "grid size-9 shrink-0 place-items-center overflow-hidden rounded-full border border-gold/40 bg-primary/10 text-xs font-bold text-primary",
        className,
      )}
    >
      {url ? (
        <img src={url} alt={name ?? "Profile photo"} className="size-full object-cover" />
      ) : (
        initialsOf(name)
      )}
    </span>
  );
}

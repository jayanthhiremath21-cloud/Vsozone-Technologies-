import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { COMPANY, industries, serviceJourney, type Product, type Category } from "@/lib/site-data";
import { useEnquiry } from "./enquiry";
import { Reveal } from "./reveal";

export function Section({
  children,
  className,
  id,
  tone = "light",
}: {
  children: ReactNode;
  className?: string;
  id?: string;
  tone?: "light" | "muted" | "deep";
}) {
  return (
    <section
      id={id}
      className={cn(
        "px-4 py-20 lg:px-6 lg:py-28",
        tone === "muted" && "bg-secondary/60",
        tone === "deep" && "surface-deep",
        className,
      )}
    >
      <div className="mx-auto max-w-7xl">{children}</div>
    </section>
  );
}

export function SectionHead({
  eyebrow,
  title,
  subtitle,
  tone = "light",
  align = "left",
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  tone?: "light" | "deep";
  align?: "left" | "center";
}) {
  return (
    <Reveal className={cn("max-w-3xl", align === "center" && "mx-auto text-center")}>
      {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
      <h2
        className={cn(
          "mt-3 text-3xl font-extrabold leading-[1.1] sm:text-4xl lg:text-[2.75rem]",
          tone === "deep" ? "text-deep-foreground" : "text-primary",
        )}
      >
        {title}
      </h2>
      <div aria-hidden className={cn("mt-5 rule-gold", align === "center" && "mx-auto")} />
      {subtitle ? (
        <p
          className={cn(
            "mt-5 text-base leading-relaxed sm:text-lg",
            tone === "deep" ? "text-deep-foreground/70" : "text-muted-foreground",
          )}
        >
          {subtitle}
        </p>
      ) : null}
    </Reveal>
  );
}

export function CategoryCard({ category, delay = 0 }: { category: Category; delay?: number }) {
  return (
    <Reveal delay={delay} className="h-full">
      <article className="card-lift group flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card">
        <div className="relative aspect-[16/10] overflow-hidden">
          <img
            src={category.image}
            alt={category.title}
            loading="lazy"
            className="size-full object-cover transition-transform duration-[900ms] group-hover:scale-[1.06]"
          />
          <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-transparent" />
          <span className="absolute top-4 left-4 rounded-md bg-deep/85 px-2.5 py-1 text-xs font-bold tracking-[0.2em] text-gold backdrop-blur">
            {category.index}
          </span>
          <h3 className="absolute bottom-4 left-4 right-4 text-xl font-bold text-deep-foreground">
            {category.title}
          </h3>
        </div>
        <div className="flex flex-1 flex-col p-6">
          <p className="text-sm leading-relaxed text-muted-foreground">{category.blurb}</p>
          <ul className="mt-5 grid flex-1 gap-2">
            {category.items.map((item) => (
              <li key={item} className="flex items-start gap-2 text-sm text-foreground/85">
                <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-gold" />
                {item}
              </li>
            ))}
          </ul>
          {category.note ? (
            <p className="mt-4 rounded-md border border-gold/30 bg-gold/8 px-3 py-2 text-xs font-medium text-primary">
              {category.note}
            </p>
          ) : null}
          <Link
            to="/products"
            search={{ category: category.slug }}
            className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-primary transition-colors hover:text-gold"
          >
            {category.cta}
            <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>
        </div>
      </article>
    </Reveal>
  );
}

export function ProductCard({ product, delay = 0 }: { product: Product; delay?: number }) {
  const { open } = useEnquiry();
  return (
    <Reveal delay={delay} className="h-full">
      <article className="card-lift group flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card">
        <div className="relative aspect-[4/3] overflow-hidden bg-secondary">
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="size-full object-cover transition-transform duration-[900ms] group-hover:scale-[1.05]"
          />
          <span className="absolute top-3 left-3 rounded bg-background/90 px-2 py-1 text-[0.65rem] font-bold uppercase tracking-[0.14em] text-primary">
            {product.category}
          </span>
        </div>
        <div className="flex flex-1 flex-col p-5">
          <h3 className="text-base font-bold text-primary">{product.name}</h3>
          <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{product.short}</p>
          <dl className="mt-4 space-y-1.5 border-t border-border pt-4 text-xs">
            <div className="flex gap-2">
              <dt className="w-20 shrink-0 font-semibold uppercase tracking-wider text-muted-foreground">
                Capacity
              </dt>
              <dd className="font-semibold text-foreground">{product.capacity}</dd>
            </div>
            <div className="flex gap-2">
              <dt className="w-20 shrink-0 font-semibold uppercase tracking-wider text-muted-foreground">
                Use
              </dt>
              <dd className="text-foreground/80">{product.application}</dd>
            </div>
          </dl>
          <div className="mt-5 flex flex-1 items-end gap-2">
            <Button asChild variant="outline" size="sm" className="flex-1">
              <Link to="/products/$slug" params={{ slug: product.slug }}>
                View Details
              </Link>
            </Button>
            <Button size="sm" className="flex-1" onClick={() => open(product.name)}>
              Get Quote
            </Button>
          </div>
        </div>
      </article>
    </Reveal>
  );
}

export function IndustryExplorer() {
  const [active, setActive] = useState(0);
  const current = industries[active]!;

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.15fr] lg:items-stretch">
      <div className="flex flex-wrap gap-2 lg:flex-col lg:flex-nowrap">
        {industries.map((industry, i) => (
          <button
            key={industry.name}
            type="button"
            onMouseEnter={() => setActive(i)}
            onFocus={() => setActive(i)}
            onClick={() => setActive(i)}
            aria-pressed={i === active}
            className={cn(
              "group flex items-center justify-between gap-3 rounded-md border px-4 py-3 text-left text-sm font-semibold transition-all duration-300",
              i === active
                ? "border-gold bg-gold/12 text-primary"
                : "border-border bg-card text-foreground/75 hover:border-gold/50 hover:text-primary",
            )}
          >
            {industry.name}
            <ArrowRight
              className={cn(
                "size-4 shrink-0 transition-all duration-300",
                i === active ? "text-gold opacity-100" : "opacity-0 group-hover:opacity-60",
              )}
            />
          </button>
        ))}
      </div>

      <div className="relative min-h-[320px] overflow-hidden rounded-xl border border-border lg:min-h-full">
        {industries.map((industry, i) => (
          <img
            key={industry.name}
            src={industry.image}
            alt={industry.name}
            loading="lazy"
            className={cn(
              "absolute inset-0 size-full object-cover transition-opacity duration-700",
              i === active ? "opacity-100" : "opacity-0",
            )}
          />
        ))}
        <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/40 to-transparent" />
        <div className="relative flex h-full min-h-[320px] flex-col justify-end p-7">
          <p className="eyebrow">Industry</p>
          <h3 className="mt-2 text-2xl font-bold text-deep-foreground sm:text-3xl">
            {current.name}
          </h3>
          <p className="mt-3 max-w-md text-sm text-deep-foreground/80 sm:text-base">
            {current.description}
          </p>
        </div>
      </div>
    </div>
  );
}

export function ServiceJourney() {
  return (
    <div className="-mx-4 mt-12 overflow-x-auto px-4 pb-3 lg:mx-0 lg:px-0">
      <ol className="flex min-w-max items-center gap-3">
        {serviceJourney.map((step, i) => (
          <li key={step} className="flex items-center gap-3">
            <div className="rounded-md border border-gold/30 bg-card px-4 py-3 text-center shadow-[var(--shadow-card)]">
              <span className="block text-[0.65rem] font-bold tracking-[0.18em] text-gold">
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="mt-1 block text-sm font-bold text-primary">{step}</span>
            </div>
            {i < serviceJourney.length - 1 ? (
              <span aria-hidden className="h-[2px] w-8 rounded-full bg-gold/40" />
            ) : null}
          </li>
        ))}
      </ol>
    </div>
  );
}

export function EnquiryCta() {
  const { open } = useEnquiry();
  return (
    <Section tone="deep" className="relative overflow-hidden">
      <div aria-hidden className="pointer-events-none absolute inset-0 grid-tech opacity-40" />
      <div className="relative grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:items-center">
        <div>
          <p className="eyebrow">Get in touch</p>
          <h2 className="mt-3 text-3xl font-extrabold text-deep-foreground sm:text-4xl">
            Tell us what you need to weigh, count or secure.
          </h2>
          <p className="mt-4 max-w-xl text-deep-foreground/70">
            Share your requirement and our team will recommend the right equipment, capacity and
            service plan for your operation.
          </p>
        </div>
        <div className="flex flex-col gap-3">
          <Button variant="gold" size="lg" onClick={() => open("General enquiry")}>
            Request a Quote
          </Button>
          <Button variant="outlineLight" size="lg" asChild>
            <a href={COMPANY.whatsappHref} target="_blank" rel="noopener noreferrer">
              WhatsApp Us
            </a>
          </Button>
          <Button variant="outlineLight" size="lg" asChild>
            <a href={COMPANY.phoneHref}>Call {COMPANY.phone}</a>
          </Button>
        </div>
      </div>
    </Section>
  );
}

import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Package,
  Boxes,
  TicketPercent,
  Star,
  FolderTree,
  MapPin,
  FileText,
  Users,
  ShoppingCart,
  LifeBuoy,
  ShieldCheck,
  LogOut,
  Sparkles,
  Briefcase,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useAuth, canAccessArea } from "@/hooks/use-auth";

type Item = { to: string; label: string; icon: typeof Package; area: string };

const OVERVIEW: Item[] = [
  { to: "/admin", label: "Admin Dashboard", icon: LayoutDashboard, area: "any" },
  { to: "/admin/orders", label: "Orders", icon: ShoppingCart, area: "orders" },
  { to: "/admin/support", label: "Support", icon: LifeBuoy, area: "support" },
];

const CUSTOMIZE: Item[] = [
  { to: "/admin/products", label: "Product Management", icon: Package, area: "products" },
  { to: "/admin/inventory", label: "Inventory", icon: Boxes, area: "products" },
  { to: "/admin/categories", label: "Category Management", icon: FolderTree, area: "products" },
  { to: "/admin/coupons", label: "Coupons & Promotions", icon: TicketPercent, area: "marketing" },
  { to: "/admin/reviews", label: "Reviews Management", icon: Star, area: "reviews" },
  { to: "/admin/locations", label: "Delivery & Service Areas", icon: MapPin, area: "orders" },
  { to: "/admin/content", label: "Website Content", icon: FileText, area: "settings" },
];

const CRM: Item[] = [
  { to: "/dashboard", label: "CRM Dashboard", icon: Briefcase, area: "crm" },
  { to: "/contacts", label: "Contacts", icon: Users, area: "crm" },
  { to: "/deals", label: "Deals", icon: Briefcase, area: "crm" },
  { to: "/assistant", label: "AI Assistant", icon: Sparkles, area: "crm" },
  { to: "/customers", label: "Customer Details", icon: Users, area: "crm" },
];

const SYSTEM: Item[] = [
  { to: "/admin/staff", label: "Admin & Staff", icon: ShieldCheck, area: "staff" },
];

function NavGroup({ title, items, role }: { title: string; items: Item[]; role: string | null }) {
  const visible = items.filter(
    (i) => i.area === "any" || canAccessArea(role as never, i.area),
  );
  if (!visible.length) return null;
  return (
    <div className="mb-6">
      <p className="mb-2 px-3 text-[0.68rem] font-bold tracking-[0.18em] uppercase text-muted-foreground">
        {title}
      </p>
      <nav className="space-y-1">
        {visible.map((i) => (
          <Link
            key={i.to}
            to={i.to}
            className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-semibold text-foreground/70 transition-colors hover:bg-primary/5 hover:text-primary"
            activeProps={{ className: "bg-primary/10 text-primary" }}
            activeOptions={{ exact: i.to === "/admin" }}
          >
            <i.icon className="size-4 shrink-0" />
            <span className="truncate">{i.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}

/** Admin layout. Also acts as a client-side gate; the database enforces the real rules. */
export function AdminShell({
  title,
  description,
  actions,
  area,
  children,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
  area?: string;
  children: React.ReactNode;
}) {
  const { staffRole, staffLoading, loading } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const allowed = staffRole ? (area ? canAccessArea(staffRole, area) : true) : false;

  useEffect(() => {
    if (loading || staffLoading) return;
    if (!allowed) navigate({ to: "/profile", replace: true });
  }, [allowed, loading, staffLoading, navigate]);

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/", replace: true });
  }

  if (loading || staffLoading) {
    return <div className="p-10 text-sm text-muted-foreground">Checking permissions…</div>;
  }
  if (!allowed) {
    return <div className="p-10 text-sm text-muted-foreground">Access denied.</div>;
  }

  return (
    <div className="min-h-screen bg-muted/30 lg:flex">
      <aside className="border-b border-border bg-background lg:min-h-screen lg:w-64 lg:shrink-0 lg:border-r lg:border-b-0">
        <div className="flex items-center justify-between px-4 py-4">
          <Link to="/" className="text-xs font-bold tracking-[0.2em] uppercase text-gold">
            VSOZONE ADMIN
          </Link>
          <Button variant="ghost" size="sm" onClick={signOut} aria-label="Logout">
            <LogOut className="size-4" />
          </Button>
        </div>
        <div className="max-h-[45vh] overflow-y-auto px-2 pb-4 lg:max-h-none">
          <NavGroup title="Overview" items={OVERVIEW} role={staffRole} />
          <NavGroup title="Customize" items={CUSTOMIZE} role={staffRole} />
          <NavGroup title="CRM" items={CRM} role={staffRole} />
          <NavGroup title="System" items={SYSTEM} role={staffRole} />
        </div>
      </aside>

      <main className="min-w-0 flex-1 px-4 py-8 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-primary lg:text-3xl">{title}</h1>
            {description ? <p className="mt-1 text-sm text-muted-foreground">{description}</p> : null}
            <div aria-hidden className="mt-3 rule-gold" />
          </div>
          {actions}
        </div>
        <div className="mt-8 pb-16">{children}</div>
      </main>
    </div>
  );
}

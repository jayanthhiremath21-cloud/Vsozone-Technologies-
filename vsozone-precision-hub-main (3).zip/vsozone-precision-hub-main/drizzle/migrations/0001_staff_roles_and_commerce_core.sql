-- ============ STAFF ROLES ============
CREATE TYPE public.staff_role AS ENUM (
  'super_admin','product_manager','order_manager','crm_manager','marketing_manager','support_manager'
);

CREATE TABLE public.staff_emails (
  email text PRIMARY KEY,
  role public.staff_role NOT NULL DEFAULT 'super_admin',
  added_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.staff_emails TO authenticated;
GRANT ALL ON public.staff_emails TO service_role;
ALTER TABLE public.staff_emails ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.staff_members (
  user_id uuid PRIMARY KEY,
  role public.staff_role NOT NULL,
  added_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.staff_members TO authenticated;
GRANT ALL ON public.staff_members TO service_role;
ALTER TABLE public.staff_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.staff_role_of(_user_id uuid)
RETURNS public.staff_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE(
    (SELECT s.role FROM public.staff_members s WHERE s.user_id = _user_id),
    CASE WHEN public.has_role(_user_id, 'admin') THEN 'super_admin'::public.staff_role ELSE NULL END
  );
$$;

CREATE OR REPLACE FUNCTION public.is_staff(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.staff_role_of(_user_id) IS NOT NULL;
$$;

CREATE OR REPLACE FUNCTION public.is_super_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.staff_role_of(_user_id) = 'super_admin';
$$;

-- areas: products | orders | crm | marketing | support
CREATE OR REPLACE FUNCTION public.has_area(_user_id uuid, _area text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE public.staff_role_of(_user_id)
    WHEN 'super_admin' THEN true
    WHEN 'product_manager' THEN _area = 'products'
    WHEN 'order_manager' THEN _area IN ('orders','products')
    WHEN 'crm_manager' THEN _area IN ('crm','reviews')
    WHEN 'marketing_manager' THEN _area = 'marketing'
    WHEN 'support_manager' THEN _area IN ('support','orders')
    ELSE false
  END;
$$;

CREATE POLICY staff_members_select ON public.staff_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_staff(auth.uid()));
CREATE POLICY staff_emails_select ON public.staff_emails FOR SELECT TO authenticated
  USING (public.is_staff(auth.uid()));

-- seed super admins
INSERT INTO public.staff_emails (email, role) VALUES
  ('jayanthhiremath21@gmail.com','super_admin'),
  ('vsozonetech@gmail.com','super_admin')
ON CONFLICT (email) DO NOTHING;

INSERT INTO public.staff_members (user_id, role)
SELECT u.id, se.role FROM auth.users u
JOIN public.staff_emails se ON lower(se.email) = lower(u.email)
ON CONFLICT (user_id) DO NOTHING;

CREATE OR REPLACE FUNCTION public.sync_staff_on_auth()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.staff_members (user_id, role)
  SELECT NEW.id, se.role FROM public.staff_emails se WHERE lower(se.email) = lower(NEW.email)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created_sync_staff AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.sync_staff_on_auth();
CREATE TRIGGER on_auth_user_updated_sync_staff AFTER UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.sync_staff_on_auth();

-- staff management RPCs (super admin only)
CREATE OR REPLACE FUNCTION public.admin_list_staff()
RETURNS TABLE(email text, role public.staff_role, created_at timestamptz, is_registered boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_super_admin(auth.uid()) THEN RAISE EXCEPTION 'Not authorized'; END IF;
  RETURN QUERY
  SELECT se.email, se.role, se.created_at,
         EXISTS (SELECT 1 FROM auth.users u WHERE lower(u.email) = lower(se.email))
  FROM public.staff_emails se ORDER BY se.created_at;
END; $$;

CREATE OR REPLACE FUNCTION public.admin_upsert_staff(_email text, _role public.staff_role)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_email text := lower(trim(_email));
BEGIN
  IF NOT public.is_super_admin(auth.uid()) THEN RAISE EXCEPTION 'Not authorized'; END IF;
  IF v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' THEN RAISE EXCEPTION 'Invalid email'; END IF;
  INSERT INTO public.staff_emails (email, role, added_by) VALUES (v_email, _role, auth.uid())
  ON CONFLICT (email) DO UPDATE SET role = EXCLUDED.role;
  INSERT INTO public.staff_members (user_id, role, added_by)
  SELECT u.id, _role, auth.uid() FROM auth.users u WHERE lower(u.email) = v_email
  ON CONFLICT (user_id) DO UPDATE SET role = EXCLUDED.role;
END; $$;

CREATE OR REPLACE FUNCTION public.admin_remove_staff(_email text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_email text := lower(trim(_email));
BEGIN
  IF NOT public.is_super_admin(auth.uid()) THEN RAISE EXCEPTION 'Not authorized'; END IF;
  IF EXISTS (SELECT 1 FROM auth.users u WHERE u.id = auth.uid() AND lower(u.email) = v_email) THEN
    RAISE EXCEPTION 'You cannot remove your own access';
  END IF;
  IF (SELECT count(*) FROM public.staff_emails WHERE role = 'super_admin') <= 1
     AND EXISTS (SELECT 1 FROM public.staff_emails WHERE email = v_email AND role = 'super_admin') THEN
    RAISE EXCEPTION 'At least one super admin must remain';
  END IF;
  DELETE FROM public.staff_emails WHERE email = v_email;
  DELETE FROM public.staff_members sm USING auth.users u
    WHERE sm.user_id = u.id AND lower(u.email) = v_email;
END; $$;

-- ============ LOCK DOWN CRM DATA TO STAFF ============
DROP POLICY IF EXISTS contacts_own ON public.contacts;
CREATE POLICY contacts_staff ON public.contacts FOR ALL TO authenticated
  USING (auth.uid() = user_id AND public.has_area(auth.uid(), 'crm'))
  WITH CHECK (auth.uid() = user_id AND public.has_area(auth.uid(), 'crm'));

DROP POLICY IF EXISTS deals_own ON public.deals;
CREATE POLICY deals_staff ON public.deals FOR ALL TO authenticated
  USING (auth.uid() = user_id AND public.has_area(auth.uid(), 'crm'))
  WITH CHECK (auth.uid() = user_id AND public.has_area(auth.uid(), 'crm'));

-- ============ CATALOGUE ============
CREATE TYPE public.product_status AS ENUM ('active','draft','low_stock','out_of_stock','hidden','discontinued');
CREATE TYPE public.media_type AS ENUM ('image','video','promo_video');

CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  description text,
  image_url text,
  parent_id uuid REFERENCES public.categories(id) ON DELETE CASCADE,
  sort_order int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY categories_public_read ON public.categories FOR SELECT TO anon, authenticated USING (is_active);
CREATE POLICY categories_staff_all ON public.categories FOR ALL TO authenticated
  USING (public.has_area(auth.uid(),'products')) WITH CHECK (public.has_area(auth.uid(),'products'));
CREATE TRIGGER categories_updated_at BEFORE UPDATE ON public.categories
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  short_description text,
  description text,
  category_id uuid REFERENCES public.categories(id) ON DELETE SET NULL,
  subcategory_id uuid REFERENCES public.categories(id) ON DELETE SET NULL,
  brand text,
  features text[] NOT NULL DEFAULT '{}',
  specifications jsonb NOT NULL DEFAULT '{}'::jsonb,
  variants jsonb NOT NULL DEFAULT '[]'::jsonb,
  price numeric(12,2) NOT NULL DEFAULT 0,
  discount_price numeric(12,2),
  mrp numeric(12,2),
  gst_rate numeric(5,2) NOT NULL DEFAULT 18,
  sku text UNIQUE,
  stock_quantity int NOT NULL DEFAULT 0,
  low_stock_threshold int NOT NULL DEFAULT 5,
  thumbnail_url text,
  weight text,
  dimensions text,
  delivery_info text,
  warranty text,
  return_policy text,
  status public.product_status NOT NULL DEFAULT 'draft',
  unavailable_reason text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX products_category_idx ON public.products(category_id);
CREATE INDEX products_status_idx ON public.products(status);
GRANT SELECT ON public.products TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY products_public_read ON public.products FOR SELECT TO anon, authenticated
  USING (status IN ('active','low_stock','out_of_stock'));
CREATE POLICY products_staff_all ON public.products FOR ALL TO authenticated
  USING (public.has_area(auth.uid(),'products')) WITH CHECK (public.has_area(auth.uid(),'products'));
CREATE TRIGGER products_updated_at BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.sync_product_stock_status()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.status IN ('draft','hidden','discontinued') THEN RETURN NEW; END IF;
  IF NEW.stock_quantity <= 0 THEN NEW.status := 'out_of_stock';
  ELSIF NEW.stock_quantity <= NEW.low_stock_threshold THEN NEW.status := 'low_stock';
  ELSE NEW.status := 'active';
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER products_stock_status BEFORE INSERT OR UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.sync_product_stock_status();

CREATE TABLE public.product_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  url text NOT NULL,
  storage_path text,
  type public.media_type NOT NULL DEFAULT 'image',
  alt text,
  sort_order int NOT NULL DEFAULT 0,
  is_primary boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX product_media_product_idx ON public.product_media(product_id);
GRANT SELECT ON public.product_media TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.product_media TO authenticated;
GRANT ALL ON public.product_media TO service_role;
ALTER TABLE public.product_media ENABLE ROW LEVEL SECURITY;
CREATE POLICY product_media_public_read ON public.product_media FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY product_media_staff_all ON public.product_media FOR ALL TO authenticated
  USING (public.has_area(auth.uid(),'products')) WITH CHECK (public.has_area(auth.uid(),'products'));

CREATE TABLE public.inventory_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  change int NOT NULL,
  resulting_stock int NOT NULL,
  reason text NOT NULL DEFAULT 'manual',
  note text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.inventory_movements TO authenticated;
GRANT ALL ON public.inventory_movements TO service_role;
ALTER TABLE public.inventory_movements ENABLE ROW LEVEL SECURITY;
CREATE POLICY inventory_staff ON public.inventory_movements FOR ALL TO authenticated
  USING (public.has_area(auth.uid(),'products')) WITH CHECK (public.has_area(auth.uid(),'products'));

-- ============ SERVICE AREAS ============
CREATE TABLE public.service_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  state text NOT NULL DEFAULT 'Karnataka',
  city text NOT NULL,
  area text,
  pincode text,
  delivery_available boolean NOT NULL DEFAULT true,
  delivery_charge numeric(10,2) NOT NULL DEFAULT 0,
  estimated_delivery text,
  cod_available boolean NOT NULL DEFAULT true,
  min_order_value numeric(12,2) NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX service_locations_pincode_idx ON public.service_locations(pincode);
GRANT SELECT ON public.service_locations TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.service_locations TO authenticated;
GRANT ALL ON public.service_locations TO service_role;
ALTER TABLE public.service_locations ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_locations_public_read ON public.service_locations FOR SELECT TO anon, authenticated USING (is_active);
CREATE POLICY service_locations_staff ON public.service_locations FOR ALL TO authenticated
  USING (public.has_area(auth.uid(),'orders')) WITH CHECK (public.has_area(auth.uid(),'orders'));
CREATE TRIGGER service_locations_updated_at BEFORE UPDATE ON public.service_locations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.service_locations (state, city, estimated_delivery, delivery_charge)
VALUES
 ('Karnataka','Kalaburagi (Gulbarga)','2-4 days',0),
 ('Karnataka','Bidar','3-5 days',0),
 ('Karnataka','Yadagir','3-5 days',0),
 ('Karnataka','Vijayapura (Bijapur)','3-5 days',0),
 ('Karnataka','Bagalkot','3-5 days',0),
 ('Karnataka','Ballari','3-5 days',0),
 ('Karnataka','Raichur','3-5 days',0),
 ('Karnataka','Mangaluru','4-6 days',0),
 ('Karnataka','Karwar','4-6 days',0),
 ('Goa','Goa','4-7 days',0),
 ('Karnataka','Bengaluru North','2-4 days',0),
 ('Karnataka','Bengaluru South','2-4 days',0),
 ('Karnataka','Belagavi','3-5 days',0);

-- ============ COUPONS ============
CREATE TYPE public.discount_type AS ENUM ('percentage','fixed');
CREATE TABLE public.coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  description text,
  discount_type public.discount_type NOT NULL DEFAULT 'percentage',
  discount_value numeric(12,2) NOT NULL DEFAULT 0,
  min_order_value numeric(12,2) NOT NULL DEFAULT 0,
  max_discount numeric(12,2),
  starts_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  usage_limit int,
  per_customer_limit int NOT NULL DEFAULT 1,
  applicable_products uuid[] NOT NULL DEFAULT '{}',
  applicable_categories uuid[] NOT NULL DEFAULT '{}',
  applicable_locations uuid[] NOT NULL DEFAULT '{}',
  is_active boolean NOT NULL DEFAULT true,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.coupons TO authenticated;
GRANT ALL ON public.coupons TO service_role;
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
CREATE POLICY coupons_staff ON public.coupons FOR ALL TO authenticated
  USING (public.has_area(auth.uid(),'marketing')) WITH CHECK (public.has_area(auth.uid(),'marketing'));
CREATE TRIGGER coupons_updated_at BEFORE UPDATE ON public.coupons
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.coupon_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  coupon_id uuid NOT NULL REFERENCES public.coupons(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  order_id uuid,
  discount_amount numeric(12,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.coupon_usage TO authenticated;
GRANT ALL ON public.coupon_usage TO service_role;
ALTER TABLE public.coupon_usage ENABLE ROW LEVEL SECURITY;
CREATE POLICY coupon_usage_select ON public.coupon_usage FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_area(auth.uid(),'marketing'));

-- ============ CART / WISHLIST ============
CREATE TABLE public.cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  quantity int NOT NULL DEFAULT 1 CHECK (quantity > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, product_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cart_items TO authenticated;
GRANT ALL ON public.cart_items TO service_role;
ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY cart_items_own ON public.cart_items FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE TRIGGER cart_items_updated_at BEFORE UPDATE ON public.cart_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.wishlists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, product_id)
);
GRANT SELECT, INSERT, DELETE ON public.wishlists TO authenticated;
GRANT ALL ON public.wishlists TO service_role;
ALTER TABLE public.wishlists ENABLE ROW LEVEL SECURITY;
CREATE POLICY wishlists_own ON public.wishlists FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- ============ ORDERS ============
CREATE TYPE public.order_status AS ENUM
 ('new','confirmed','processing','packed','dispatched','out_for_delivery','delivered','cancelled','returned','refunded');
CREATE TYPE public.payment_status AS ENUM ('pending','successful','failed','refund_initiated','refund_completed');

CREATE SEQUENCE public.order_number_seq START 10001;
CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text NOT NULL UNIQUE DEFAULT ('VSO' || nextval('public.order_number_seq')),
  user_id uuid NOT NULL,
  status public.order_status NOT NULL DEFAULT 'new',
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  discount numeric(12,2) NOT NULL DEFAULT 0,
  coupon_code text,
  delivery_charge numeric(12,2) NOT NULL DEFAULT 0,
  tax numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  payment_method text NOT NULL DEFAULT 'cod',
  payment_status public.payment_status NOT NULL DEFAULT 'pending',
  contact_name text,
  contact_phone text,
  address_line text,
  city text,
  state text,
  pincode text,
  location_id uuid REFERENCES public.service_locations(id),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX orders_user_idx ON public.orders(user_id);
CREATE INDEX orders_status_idx ON public.orders(status);
GRANT SELECT, INSERT, UPDATE ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY orders_select ON public.orders FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_area(auth.uid(),'orders'));
CREATE POLICY orders_insert_own ON public.orders FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY orders_update_staff ON public.orders FOR UPDATE TO authenticated
  USING (public.has_area(auth.uid(),'orders')) WITH CHECK (public.has_area(auth.uid(),'orders'));
CREATE TRIGGER orders_updated_at BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  sku text,
  unit_price numeric(12,2) NOT NULL DEFAULT 0,
  quantity int NOT NULL DEFAULT 1,
  total numeric(12,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX order_items_order_idx ON public.order_items(order_id);
GRANT SELECT, INSERT ON public.order_items TO authenticated;
GRANT ALL ON public.order_items TO service_role;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY order_items_select ON public.order_items FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id
    AND (o.user_id = auth.uid() OR public.has_area(auth.uid(),'orders'))));
CREATE POLICY order_items_insert ON public.order_items FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND o.user_id = auth.uid()));

CREATE TABLE public.order_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  status public.order_status NOT NULL,
  note text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.order_events TO authenticated;
GRANT ALL ON public.order_events TO service_role;
ALTER TABLE public.order_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY order_events_select ON public.order_events FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id
    AND (o.user_id = auth.uid() OR public.has_area(auth.uid(),'orders'))));
CREATE POLICY order_events_insert_staff ON public.order_events FOR INSERT TO authenticated
  WITH CHECK (public.has_area(auth.uid(),'orders'));

CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  transaction_id text,
  method text NOT NULL DEFAULT 'cod',
  status public.payment_status NOT NULL DEFAULT 'pending',
  amount numeric(12,2) NOT NULL DEFAULT 0,
  refund_amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_at timestamptz,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.payments TO authenticated;
GRANT ALL ON public.payments TO service_role;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY payments_select ON public.payments FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id
    AND (o.user_id = auth.uid() OR public.has_area(auth.uid(),'orders'))));
CREATE POLICY payments_staff_write ON public.payments FOR ALL TO authenticated
  USING (public.has_area(auth.uid(),'orders')) WITH CHECK (public.has_area(auth.uid(),'orders'));
CREATE TRIGGER payments_updated_at BEFORE UPDATE ON public.payments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ RETURNS ============
CREATE TYPE public.return_status AS ENUM ('requested','approved','rejected','picked_up','refund_initiated','refunded','closed');
CREATE TABLE public.returns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  order_item_id uuid REFERENCES public.order_items(id) ON DELETE SET NULL,
  user_id uuid NOT NULL,
  reason text NOT NULL,
  details text,
  media jsonb NOT NULL DEFAULT '[]'::jsonb,
  status public.return_status NOT NULL DEFAULT 'requested',
  pickup_status text,
  refund_amount numeric(12,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.returns TO authenticated;
GRANT ALL ON public.returns TO service_role;
ALTER TABLE public.returns ENABLE ROW LEVEL SECURITY;
CREATE POLICY returns_select ON public.returns FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_area(auth.uid(),'orders'));
CREATE POLICY returns_insert_own ON public.returns FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY returns_update_staff ON public.returns FOR UPDATE TO authenticated
  USING (public.has_area(auth.uid(),'orders')) WITH CHECK (public.has_area(auth.uid(),'orders'));
CREATE TRIGGER returns_updated_at BEFORE UPDATE ON public.returns
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ REVIEWS ============
CREATE TYPE public.review_status AS ENUM ('pending','approved','rejected','reported','featured');
CREATE TABLE public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES public.products(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  rating int NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title text,
  body text,
  media jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_verified_purchase boolean NOT NULL DEFAULT false,
  status public.review_status NOT NULL DEFAULT 'pending',
  admin_reply text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX reviews_one_per_product ON public.reviews(user_id, product_id) WHERE product_id IS NOT NULL;
CREATE UNIQUE INDEX reviews_one_company ON public.reviews(user_id) WHERE product_id IS NULL;
GRANT SELECT ON public.reviews TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reviews TO authenticated;
GRANT ALL ON public.reviews TO service_role;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY reviews_public_read ON public.reviews FOR SELECT TO anon, authenticated
  USING (status IN ('approved','featured'));
CREATE POLICY reviews_own_read ON public.reviews FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY reviews_staff_read ON public.reviews FOR SELECT TO authenticated USING (public.has_area(auth.uid(),'reviews'));
CREATE POLICY reviews_insert_own ON public.reviews FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY reviews_update_own ON public.reviews FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY reviews_staff_all ON public.reviews FOR ALL TO authenticated
  USING (public.has_area(auth.uid(),'reviews')) WITH CHECK (public.has_area(auth.uid(),'reviews'));
CREATE TRIGGER reviews_updated_at BEFORE UPDATE ON public.reviews
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.set_review_verified()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  NEW.is_verified_purchase := EXISTS (
    SELECT 1 FROM public.order_items oi
    JOIN public.orders o ON o.id = oi.order_id
    WHERE o.user_id = NEW.user_id AND o.status = 'delivered'
      AND (NEW.product_id IS NULL OR oi.product_id = NEW.product_id)
  );
  RETURN NEW;
END; $$;
CREATE TRIGGER reviews_verified BEFORE INSERT ON public.reviews
  FOR EACH ROW EXECUTE FUNCTION public.set_review_verified();

-- ============ NOTIFICATIONS / SUPPORT / AUDIT ============
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  audience text NOT NULL DEFAULT 'customer',
  type text NOT NULL,
  title text NOT NULL,
  body text,
  link text,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY notifications_select ON public.notifications FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR (audience = 'admin' AND public.is_staff(auth.uid())));
CREATE POLICY notifications_update_own ON public.notifications FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR (audience = 'admin' AND public.is_staff(auth.uid())))
  WITH CHECK (true);
CREATE POLICY notifications_insert_staff ON public.notifications FOR INSERT TO authenticated
  WITH CHECK (public.is_staff(auth.uid()));

CREATE TYPE public.ticket_status AS ENUM ('open','in_progress','waiting_for_customer','resolved','closed');
CREATE SEQUENCE public.ticket_number_seq START 1001;
CREATE TABLE public.support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_number text NOT NULL UNIQUE DEFAULT ('TCK' || nextval('public.ticket_number_seq')),
  user_id uuid NOT NULL,
  order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  category text NOT NULL DEFAULT 'other',
  subject text NOT NULL,
  message text NOT NULL,
  priority text NOT NULL DEFAULT 'normal',
  status public.ticket_status NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.support_tickets TO authenticated;
GRANT ALL ON public.support_tickets TO service_role;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY tickets_select ON public.support_tickets FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_area(auth.uid(),'support'));
CREATE POLICY tickets_insert_own ON public.support_tickets FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY tickets_update_staff ON public.support_tickets FOR UPDATE TO authenticated
  USING (public.has_area(auth.uid(),'support')) WITH CHECK (public.has_area(auth.uid(),'support'));
CREATE TRIGGER support_tickets_updated_at BEFORE UPDATE ON public.support_tickets
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.ticket_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES public.support_tickets(id) ON DELETE CASCADE,
  author_id uuid NOT NULL,
  is_staff boolean NOT NULL DEFAULT false,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.ticket_messages TO authenticated;
GRANT ALL ON public.ticket_messages TO service_role;
ALTER TABLE public.ticket_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY ticket_messages_select ON public.ticket_messages FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.support_tickets t WHERE t.id = ticket_id
    AND (t.user_id = auth.uid() OR public.has_area(auth.uid(),'support'))));
CREATE POLICY ticket_messages_insert ON public.ticket_messages FOR INSERT TO authenticated
  WITH CHECK (author_id = auth.uid() AND EXISTS (SELECT 1 FROM public.support_tickets t WHERE t.id = ticket_id
    AND (t.user_id = auth.uid() OR public.has_area(auth.uid(),'support'))));

CREATE TABLE public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid,
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.audit_logs TO authenticated;
GRANT ALL ON public.audit_logs TO service_role;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY audit_logs_select_staff ON public.audit_logs FOR SELECT TO authenticated
  USING (public.is_staff(auth.uid()));
CREATE POLICY audit_logs_insert_staff ON public.audit_logs FOR INSERT TO authenticated
  WITH CHECK (public.is_staff(auth.uid()) AND actor_id = auth.uid());

CREATE TABLE public.stock_notify_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  notified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (product_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.stock_notify_requests TO authenticated;
GRANT ALL ON public.stock_notify_requests TO service_role;
ALTER TABLE public.stock_notify_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY stock_notify_own ON public.stock_notify_requests FOR ALL TO authenticated
  USING (user_id = auth.uid() OR public.has_area(auth.uid(),'products')) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.site_content (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_content TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_content TO authenticated;
GRANT ALL ON public.site_content TO service_role;
ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;
CREATE POLICY site_content_public_read ON public.site_content FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY site_content_staff ON public.site_content FOR ALL TO authenticated
  USING (public.is_super_admin(auth.uid())) WITH CHECK (public.is_super_admin(auth.uid()));

-- ============ SERVER-SIDE COUPON VALIDATION ============
CREATE OR REPLACE FUNCTION public.validate_coupon(_code text, _order_value numeric, _location_id uuid DEFAULT NULL)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE c public.coupons%ROWTYPE; v_used int; v_user_used int; v_discount numeric;
BEGIN
  IF auth.uid() IS NULL THEN RETURN jsonb_build_object('ok',false,'error','auth','message','Please sign in to apply a coupon.'); END IF;
  SELECT * INTO c FROM public.coupons WHERE lower(code) = lower(trim(_code)) AND is_active;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'error','invalid','message','YOU HAVE ENTERED THE WRONG COUPON CODE'); END IF;
  IF c.starts_at > now() THEN RETURN jsonb_build_object('ok',false,'error','not_started','message','This coupon is not active yet.'); END IF;
  IF c.expires_at IS NOT NULL AND c.expires_at < now() THEN RETURN jsonb_build_object('ok',false,'error','expired','message','This coupon has expired.'); END IF;
  IF _order_value < c.min_order_value THEN
    RETURN jsonb_build_object('ok',false,'error','min_order','message','Add ' || to_char(c.min_order_value - _order_value, 'FM999999990') || ' more to use this coupon.');
  END IF;
  IF array_length(c.applicable_locations,1) IS NOT NULL AND (_location_id IS NULL OR NOT (_location_id = ANY(c.applicable_locations))) THEN
    RETURN jsonb_build_object('ok',false,'error','location','message','This coupon is not valid for your location.');
  END IF;
  SELECT count(*) INTO v_used FROM public.coupon_usage WHERE coupon_id = c.id;
  IF c.usage_limit IS NOT NULL AND v_used >= c.usage_limit THEN
    RETURN jsonb_build_object('ok',false,'error','limit','message','This coupon has reached its usage limit.');
  END IF;
  SELECT count(*) INTO v_user_used FROM public.coupon_usage WHERE coupon_id = c.id AND user_id = auth.uid();
  IF v_user_used >= c.per_customer_limit THEN
    RETURN jsonb_build_object('ok',false,'error','user_limit','message','You have already used this coupon.');
  END IF;
  IF c.discount_type = 'percentage' THEN v_discount := _order_value * c.discount_value / 100;
  ELSE v_discount := c.discount_value; END IF;
  IF c.max_discount IS NOT NULL THEN v_discount := least(v_discount, c.max_discount); END IF;
  v_discount := least(v_discount, _order_value);
  RETURN jsonb_build_object('ok',true,'coupon_id',c.id,'code',c.code,'discount',round(v_discount,2),'message','Coupon applied successfully!');
END; $$;

-- ============ PINCODE / SERVICEABILITY ============
CREATE OR REPLACE FUNCTION public.check_serviceability(_pincode text)
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE(
    (SELECT jsonb_build_object('ok', sl.delivery_available,'location_id',sl.id,'city',sl.city,'state',sl.state,
      'delivery_charge',sl.delivery_charge,'estimated_delivery',sl.estimated_delivery,
      'cod_available',sl.cod_available,'min_order_value',sl.min_order_value)
     FROM public.service_locations sl
     WHERE sl.is_active AND sl.pincode = trim(_pincode) LIMIT 1),
    jsonb_build_object('ok', false, 'message', 'Sorry, we currently don''t deliver to this location.')
  );
$$;

-- ============ ADMIN DASHBOARD METRICS ============
CREATE OR REPLACE FUNCTION public.admin_dashboard_metrics()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE r jsonb;
BEGIN
  IF NOT public.is_staff(auth.uid()) THEN RAISE EXCEPTION 'Not authorized'; END IF;
  SELECT jsonb_build_object(
    'todays_orders', (SELECT count(*) FROM public.orders WHERE created_at::date = current_date),
    'todays_sales', (SELECT COALESCE(sum(total),0) FROM public.orders WHERE created_at::date = current_date AND status <> 'cancelled'),
    'total_revenue', (SELECT COALESCE(sum(total),0) FROM public.orders WHERE status NOT IN ('cancelled','refunded')),
    'pending_orders', (SELECT count(*) FROM public.orders WHERE status IN ('new','confirmed')),
    'to_dispatch', (SELECT count(*) FROM public.orders WHERE status IN ('processing','packed')),
    'delivered_orders', (SELECT count(*) FROM public.orders WHERE status = 'delivered'),
    'cancelled_orders', (SELECT count(*) FROM public.orders WHERE status = 'cancelled'),
    'return_requests', (SELECT count(*) FROM public.returns WHERE status IN ('requested','approved')),
    'low_stock', (SELECT count(*) FROM public.products WHERE status = 'low_stock'),
    'out_of_stock', (SELECT count(*) FROM public.products WHERE status = 'out_of_stock'),
    'new_customers', (SELECT count(*) FROM public.profiles WHERE created_at > now() - interval '30 days'),
    'new_reviews', (SELECT count(*) FROM public.reviews WHERE status = 'pending'),
    'average_rating', (SELECT COALESCE(round(avg(rating),2),0) FROM public.reviews WHERE status IN ('approved','featured')),
    'active_coupons', (SELECT count(*) FROM public.coupons WHERE is_active AND (expires_at IS NULL OR expires_at > now())),
    'not_deliverable', (SELECT count(*) FROM public.service_locations WHERE NOT delivery_available),
    'open_tickets', (SELECT count(*) FROM public.support_tickets WHERE status IN ('open','in_progress')),
    'sales_by_city', (SELECT COALESCE(jsonb_agg(x), '[]'::jsonb) FROM (
        SELECT COALESCE(city,'Unknown') AS city, count(*) AS orders, COALESCE(sum(total),0) AS revenue
        FROM public.orders WHERE status <> 'cancelled' GROUP BY 1 ORDER BY 3 DESC LIMIT 12) x)
  ) INTO r;
  RETURN r;
END; $$;